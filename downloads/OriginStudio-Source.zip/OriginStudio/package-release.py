"""Package the existing audited Windows build; no network or build dependencies."""
from pathlib import Path
import hashlib
import shutil
import zipfile

VERSION = "1.1"
root = Path(__file__).resolve().parent
out = root.parent / "deliverables"
stage = root.parent / "release" / ("OriginStudio-" + VERSION)
stage.mkdir(parents=True, exist_ok=True)
for name in ["OriginStudio-" + VERSION + ".exe", "OriginStudio-Setup-" + VERSION + ".exe"]:
    path = out / name
    if not path.is_file() or path.read_bytes()[:2] != b"MZ":
        raise SystemExit("Build the Windows executables before packaging: " + name)
    shutil.copy2(path, stage / name)
for name in ["README.md", "CHANGELOG.md"]:
    shutil.copy2(root / name, stage / name)
shutil.copy2(root / "assets/catalog-sources.txt", stage / "catalog-sources.txt")
shots = stage / "screenshots"
shots.mkdir(exist_ok=True)
(shots / "ADD-YOUR-SCREENSHOTS.txt").write_text(
    "Add your app screenshot as app.png and your exported metadata screenshot as metadata.png.\n"
    "In README.md, replace the two screenshot placeholders with the Markdown image lines provided in comments.\n",
    encoding="utf-8",
)
files = sorted(p for p in stage.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt")
(stage / "SHA256SUMS.txt").write_text(
    "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.relative_to(stage).as_posix() + "\n" for p in files),
    encoding="utf-8",
)
with zipfile.ZipFile(out / ("OriginStudio-Release-" + VERSION + ".zip"), "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(stage.rglob("*")):
        if path.is_file():
            archive.write(path, path.relative_to(stage.parent))
source_files = [root / name for name in [
    "README.md", "CHANGELOG.md", "BUILDING.md", "build-cross.py", "build-windows.cmd",
    "build-installer.cmd", "package-release.py", "installer.nsi", "app.manifest", "OriginStudio.Editor.exe.config",
    "assets/devices.tsv", "assets/sample.jpg", "assets/origin.ico", "assets/catalog-sources.txt",
    "tools/FrameworkAudit.cs",
]] + sorted((root / "src").glob("*.cs"))
with zipfile.ZipFile(out / "OriginStudio-Source.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in source_files:
        archive.write(path, "OriginStudio/" + path.relative_to(root).as_posix())
shutil.copy2(root / "README.md", out / "OriginStudio-README.md")
for path in [out / ("OriginStudio-Release-" + VERSION + ".zip"), out / "OriginStudio-Source.zip"]:
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit("Invalid ZIP member: " + bad)
    print(path.name, path.stat().st_size, "bytes; ZIP verified")
