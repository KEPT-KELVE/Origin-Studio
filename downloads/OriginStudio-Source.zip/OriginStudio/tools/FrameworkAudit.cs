using System;
using System.IO;
using System.Collections.Generic;
using Mono.Cecil;

// Validate compiled method and field references against Windows framework
// assemblies, without letting the inspection runtime resolve its own libraries.
sealed class PinnedResolver : IAssemblyResolver {
    readonly string directory;
    readonly Dictionary<string,AssemblyDefinition> assemblies=new Dictionary<string,AssemblyDefinition>();
    public PinnedResolver(string path){directory=Path.GetFullPath(path);}
    public AssemblyDefinition Resolve(AssemblyNameReference name){return Resolve(name,new ReaderParameters());}
    public AssemblyDefinition Resolve(AssemblyNameReference name,ReaderParameters parameters){
        AssemblyDefinition assembly;if(assemblies.TryGetValue(name.Name,out assembly))return assembly;
        string path=Path.Combine(directory,name.Name+".dll");
        if(!File.Exists(path))path=Path.Combine(Path.Combine(directory,"Facades"),name.Name+".dll");
        if(!File.Exists(path))throw new AssemblyResolutionException(name);
        parameters.AssemblyResolver=this;assembly=AssemblyDefinition.ReadAssembly(path,parameters);assemblies.Add(name.Name,assembly);return assembly;
    }
    public void Dispose(){foreach(var assembly in assemblies.Values)assembly.Dispose();}
}
static class FrameworkAudit {
    static int Main(string[] args){
        if(args.Length!=2){Console.Error.WriteLine("Usage: FrameworkAudit.exe app.exe Windows-reference-directory");return 2;}
        int checkedCount=0,failed=0;
        using(var resolver=new PinnedResolver(args[1]))using(var app=AssemblyDefinition.ReadAssembly(args[0],new ReaderParameters{AssemblyResolver=resolver})){
            foreach(var reference in app.MainModule.GetMemberReferences()){
                var scope=reference.DeclaringType.GetElementType().Scope as AssemblyNameReference;
                if(scope==null)continue;
                if(scope.Name!="mscorlib"&&!scope.Name.StartsWith("System",StringComparison.Ordinal))continue;
                checkedCount++;
                try {
                    var method=reference as MethodReference;
                    var field=reference as FieldReference;
                    if(method!=null&&method.Resolve()==null||field!=null&&field.Resolve()==null)throw new InvalidOperationException("No matching Windows framework member");
                }catch(Exception ex){failed++;Console.Error.WriteLine("MISSING: "+reference.FullName+" — "+ex.Message);}
            }
        }
        Console.WriteLine("Audited "+checkedCount+" framework member references; "+failed+" missing.");return failed==0?0:1;
    }
}
