using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace OriginStudio {
public static class RasterFilters {
    public static void Blur(Bitmap bitmap,int radius){
        if(radius<1)return;var bytes=Pixels.Read(bitmap);int w=bitmap.Width,h=bitmap.Height;var values=new float[bytes.Length];var tmp=new float[bytes.Length];
        for(int i=0;i<bytes.Length;i+=4){float alpha=bytes[i+3]/255f;values[i]=bytes[i]*alpha;values[i+1]=bytes[i+1]*alpha;values[i+2]=bytes[i+2]*alpha;values[i+3]=bytes[i+3];}
        for(int pass=0;pass<2;pass++){
            for(int y=0;y<h;y++)for(int c=0;c<4;c++){float sum=0;for(int k=-radius;k<=radius;k++)sum+=values[(y*w+Math.Max(0,Math.Min(w-1,k)))*4+c];for(int x=0;x<w;x++){tmp[(y*w+x)*4+c]=sum/(radius*2+1);sum-=values[(y*w+Math.Max(0,x-radius))*4+c];sum+=values[(y*w+Math.Min(w-1,x+radius+1))*4+c];}}
            for(int x=0;x<w;x++)for(int c=0;c<4;c++){float sum=0;for(int k=-radius;k<=radius;k++)sum+=tmp[(Math.Max(0,Math.Min(h-1,k))*w+x)*4+c];for(int y=0;y<h;y++){values[(y*w+x)*4+c]=sum/(radius*2+1);sum-=tmp[(Math.Max(0,y-radius)*w+x)*4+c];sum+=tmp[(Math.Min(h-1,y+radius+1)*w+x)*4+c];}}
        }
        for(int i=0;i<bytes.Length;i+=4){float alpha=values[i+3]/255f;for(int c=0;c<3;c++)bytes[i+c]=(byte)Math.Max(0,Math.Min(255,alpha<.0001?0:values[i+c]/alpha));bytes[i+3]=(byte)Math.Max(0,Math.Min(255,values[i+3]));}Pixels.Write(bitmap,bytes);
    }
    public static void Apply(Bitmap bitmap,ColorSettings settings,float scale){
        int cell=Math.Max(1,(int)(settings.Pixelate*scale));if(cell>1){int width=Math.Max(1,bitmap.Width/cell),height=Math.Max(1,bitmap.Height/cell);using(var small=new Bitmap(width,height)){using(var g=Graphics.FromImage(small)){g.InterpolationMode=InterpolationMode.HighQualityBilinear;g.DrawImage(bitmap,new Rectangle(0,0,width,height));}using(var g=Graphics.FromImage(bitmap)){g.CompositingMode=CompositingMode.SourceCopy;g.InterpolationMode=InterpolationMode.NearestNeighbor;g.PixelOffsetMode=PixelOffsetMode.Half;g.DrawImage(small,new Rectangle(0,0,bitmap.Width,bitmap.Height));}}}
        if(settings.Blur>0)Blur(bitmap,Math.Max(1,(int)(settings.Blur*scale)));
        if(settings.Sharpen>0){var src=Pixels.Read(bitmap);var dst=(byte[])src.Clone();int w=bitmap.Width,h=bitmap.Height;float amount=settings.Sharpen;for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=(y*w+x)*4;if(src[i+3]==0)continue;for(int c=0;c<3;c++){float neighbors=(src[i-4+c]+src[i+4+c]+src[i-w*4+c]+src[i+w*4+c])/4f;dst[i+c]=(byte)Math.Max(0,Math.Min(255,src[i+c]+(src[i+c]-neighbors)*amount));}}Pixels.Write(bitmap,dst);}
    }
    public static Bitmap RemoveColor(Bitmap source,Color target,int tolerance,int softness){
        var b=Pixels.Copy(source,2048);var a=Pixels.Read(b);for(int i=0;i<a.Length;i+=4){double distance=Math.Sqrt((a[i+2]-target.R)*(a[i+2]-target.R)+(a[i+1]-target.G)*(a[i+1]-target.G)+(a[i]-target.B)*(a[i]-target.B))/Math.Sqrt(3);int coverage=(int)(Math.Max(0,Math.Min(1,(distance-tolerance)/(double)Math.Max(1,softness)))*255);a[i]=a[i+1]=a[i+2]=(byte)coverage;a[i+3]=255;}Pixels.Write(b,a);return b;
    }
    public static Bitmap Gradient(int width,int height,Color from,Color to,float angle,bool radial){
        var b=new Bitmap(width,height,PixelFormat.Format32bppArgb);using(var g=Graphics.FromImage(b)){
            if(radial)using(var path=new GraphicsPath()){path.AddEllipse(-width*.2f,-height*.2f,width*1.4f,height*1.4f);using(var brush=new PathGradientBrush(path)){brush.CenterColor=from;brush.SurroundColors=new[]{to};g.FillRectangle(brush,0,0,width,height);}}
            else using(var brush=new LinearGradientBrush(new Rectangle(0,0,width,height),from,to,angle))g.FillRectangle(brush,0,0,width,height);
        }return b;
    }
}
}
