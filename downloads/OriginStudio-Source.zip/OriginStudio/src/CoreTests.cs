using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace OriginStudio {
static class CoreTests {
    static int tests;
    static void Check(bool ok,string name){if(!ok)throw new Exception("FAILED: "+name);Console.WriteLine("PASS: "+name);tests++;}
    static byte[] Scan(byte[] b){for(int p=2;p+4<b.Length;){if(b[p++]!=255)break;byte marker=b[p++];if(marker==0xda)return b.Skip(p-2).ToArray();p+=(b[p]<<8)|b[p+1];}throw new Exception("No image scan.");}
    static void Main(string[] args){
        string dir=args[0];Directory.CreateDirectory(dir);byte[] jpg=File.ReadAllBytes(args[1]);var meta=new Metadata();
        meta.Set("IFD0",0x010f,2,"Apple");meta.Set("IFD0",0x0110,2,"iPhone X");meta.Set("IFD0",0x0131,2,"Custom OS 9");meta.Set("Exif",0x9003,2,"2024:04:01 12:34:56");meta.Set("Exif",0x9011,2,"+03:00");meta.Set("Exif",0x8827,3,"200");meta.Set("Exif",0x829a,5,"1/250");meta.Set("Exif",0x829d,5,"1.8");meta.Set("Exif",0x9204,10,"-1/3");meta.Set("Exif",0xa434,2,"Custom wide lens");meta.Set("Exif",0xa002,4,"1600");meta.Set("Exif",0xa003,4,"1050");meta.Set("IFD0",0xf123,2,"User-defined custom camera info");meta.Set("Interop",1,2,"R98");meta.SetGps(-33.8688197,151.2092955,-42.5);meta.Text["title"]="Arabic title: تجربة";meta.Text["creator"]="Adam Ali";meta.Text["Location"]="Custom place";meta.Text["City"]="Sydney";meta.Text["Country"]="Australia";meta.Text["Keywords"]="photo,custom,test";
        byte[] edited=Metadata.EmbedJpeg(jpg,meta);File.WriteAllBytes(Path.Combine(dir,"identity.jpg"),edited);var read=Metadata.Read(edited);
        Check(read.Get("IFD0",0x0110)=="iPhone X","JPEG camera model round trip");Check(read.Get("IFD0",0x010f)=="Apple","JPEG manufacturer round trip");Check(read.Get("Exif",0x9003)=="2024:04:01 12:34:56","EXIF timestamp");Check(Math.Abs(read.Coordinate(true).Value+33.8688197)<1e-7,"Southern latitude precision");Check(Math.Abs(read.Coordinate(false).Value-151.2092955)<1e-7,"Eastern longitude precision");Check(read.Get("GPS",5)=="1"&&Math.Abs(read.Number("GPS",6)-42.5)<1e-6,"Negative altitude reference");Check(read.Get("Exif",0x829a)=="1/250","Rational shutter");Check(read.Get("Exif",0x9204)=="-1/3","Signed exposure bias");Check(read.Get("Interop",1)=="R98","Interop directory pointer");Check(read.Get("IFD0",0xf123)=="User-defined custom camera info","Custom EXIF tag");Check(read.Text["title"]=="Arabic title: تجربة","Unicode XMP title");Check(read.Text["City"]=="Sydney","XMP city label");var json=new JavaScriptSerializer().Serialize(meta);var restored=new JavaScriptSerializer().Deserialize<Metadata>(json);Check(restored.Get("IFD0",0x0110)=="iPhone X"&&restored.Text["City"]=="Sydney","Metadata project JSON round trip");Check(Scan(jpg).SequenceEqual(Scan(edited)),"Metadata-only JPEG preserves compressed pixels");
        var second=read.Clone();second.Set("IFD0",0x010f,2,"samsung");second.Set("IFD0",0x0110,2,"SM-S928B");second.SetGps(29.3123,-47.9912,0);byte[] rewritten=Metadata.EmbedJpeg(edited,second);var reread=Metadata.Read(rewritten);Check(reread.Get("IFD0",0x0110)=="SM-S928B","Rewriting replaces previous model");Check(reread.Tags.Count(t=>t.Id==0x0110)==1,"No duplicate model tag");Check(reread.Coordinate(false)<0,"Western longitude sign");File.WriteAllBytes(Path.Combine(dir,"samsung.jpg"),rewritten);
        byte[] stripped=Metadata.EmbedJpeg(edited,meta,true);File.WriteAllBytes(Path.Combine(dir,"stripped.jpg"),stripped);Check(Metadata.Read(stripped).Tags.Count==0&&Metadata.Read(stripped).Text.Count==0,"JPEG strip removes all editable metadata");Check(Scan(jpg).SequenceEqual(Scan(stripped)),"Stripping JPEG preserves compressed pixels");
        byte[] png;using(var image=Image.FromStream(new MemoryStream(jpg)))using(var b=new Bitmap(image))using(var ms=new MemoryStream()){b.Save(ms,ImageFormat.Png);png=ms.ToArray();}
        byte[] annotated=Metadata.EmbedPng(png,meta);File.WriteAllBytes(Path.Combine(dir,"identity.png"),annotated);var pr=Metadata.Read(annotated);Check(pr.Get("IFD0",0x0110)=="iPhone X","PNG EXIF camera");Check(Math.Abs(pr.Coordinate(true).Value+33.8688197)<1e-7,"PNG EXIF GPS");Check(pr.Text["title"]=="Arabic title: تجربة","PNG iTXt Unicode XMP");using(var b=Image.FromStream(new MemoryStream(annotated)))Check(b.Width==1600&&b.Height==1050,"PNG with metadata decodes successfully");Check(Metadata.Read(Metadata.EmbedPng(annotated,meta,true)).Tags.Count==0,"PNG strip mode");
        var zero=new Metadata();zero.SetGps(0,0);var zr=Metadata.Read(Metadata.EmbedJpeg(jpg,zero));Check(zr.Coordinate(true)==0&&zr.Coordinate(false)==0,"Zero coordinates are valid");
        double lat,lon;Check(Network.ParseLocation("https://www.google.com/maps/place/test/@29.1,47.2,18z/data=!3d29.333!4d47.444",out lat,out lon)&&lat==29.333&&lon==47.444,"Google Maps uses precise place pin before viewport center");Check(Network.ParseLocation("-33.8688, 151.2093",out lat,out lon)&&lat<0&&lon>0,"Coordinate paste");Check(!Network.ParseLocation("100, 200",out lat,out lon),"Invalid GPS rejected");
        var bigEndian=new byte[]{77,77,0,42,0,0,0,8,0,1,1,18,0,3,0,0,0,1,0,6,0,0,0,0,0,0};var bm=Metadata.Read(bigEndian);Check(bm.Get("IFD0",0x0112)=="6","Big-endian TIFF numerical metadata");
        // Independent, hand-encoded MM TIFF: Apple / iPhone X / orientation 6.
        var bigExif=new byte[]{77,77,0,42,0,0,0,8,0,3,
            1,15,0,2,0,0,0,6,0,0,0,50,
            1,16,0,2,0,0,0,9,0,0,0,56,
            1,18,0,3,0,0,0,1,0,6,0,0,
            0,0,0,0,65,112,112,108,101,0,105,80,104,111,110,101,32,88,0};
        byte[] payload=System.Text.Encoding.ASCII.GetBytes("Exif\0\0").Concat(bigExif).ToArray();int segmentLength=payload.Length+2;
        byte[] bigJpeg=new byte[]{255,216,255,225,(byte)(segmentLength>>8),(byte)segmentLength}.Concat(payload).Concat(jpg.Skip(2)).ToArray();File.WriteAllBytes(Path.Combine(dir,"big-endian.jpg"),bigJpeg);
        var br=Metadata.Read(bigJpeg);Check(br.Get("IFD0",0x010f)=="Apple"&&br.Get("IFD0",0x0110)=="iPhone X"&&br.Get("IFD0",0x0112)=="6","Big-endian JPEG camera and numerical fields decode together");
        using(var image=Image.FromStream(new MemoryStream(jpg)))using(var b=new Bitmap(image)){using(var g=Graphics.FromImage(b)){var l=new Layer{Kind="Rectangle",Bounds=new RectangleF(50,50,200,100),Color=Color.Red,Width=5,Fill=true};l.Draw(g);Check(l.Hit(new PointF(100,80),0),"Shape selection hit testing");l.Move(10,20);Check(l.Bounds.X==60&&l.Bounds.Y==70,"Layer repositioning");}Check(b.GetPixel(100,80).R>240&&b.GetPixel(100,80).G<20,"Filled shape paints actual image pixels");b.Save(Path.Combine(dir,"painted.png"),ImageFormat.Png);}
        Check(EditorCanvas.Matrix(0,1,1).Matrix00==1&&EditorCanvas.Matrix(0,1,1).Matrix11==1,"Neutral adjustment matrix");
        Device.Load();Check(Device.All.Count>600&&Device.All.Count<1000,"Catalog contains named devices instead of regional variant duplicates");Check(Device.All.Any(d=>d.Name=="iPhone X"),"iPhone X preset available");Check(Device.All.Any(d=>d.Name.Contains("S24 Ultra")),"Galaxy S24 Ultra preset available");Check(Device.All.Any(d=>d.Name.Contains("S26")),"Current Galaxy S26 preset available");
        foreach(int length in new[]{0,1,2,8,13,31,40})Check(Metadata.Read(new byte[length]).Tags.Count==0,"Malformed input is tolerated: "+length);
        Console.WriteLine("Completed "+tests+" checks.");File.WriteAllText(Path.Combine(dir,"core-test-results.txt"),tests+" checks passed.");
    }
}
}
