using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Globalization;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace OriginStudio {
public sealed class Device {
    public string Make,Name,Model,Hardware;
    public List<string> Aliases=new List<string>();
    public override string ToString(){return Name;}
    public bool Matches(string value){return !string.IsNullOrWhiteSpace(value)&&(Name.Equals(value,StringComparison.OrdinalIgnoreCase)||Model.Equals(value,StringComparison.OrdinalIgnoreCase)||Aliases.Any(a=>a.Equals(value,StringComparison.OrdinalIgnoreCase)));}
    public static List<Device> All=new List<Device>();
    public static Device Find(string value){return All.FirstOrDefault(d=>d.Matches(value));}
    static string Normalize(string name){
        name=Regex.Replace(name.Trim(),@"\s+"," ");name=Regex.Replace(name,@"^GALAXY[ -]","Galaxy ",RegexOptions.IgnoreCase);
        name=Regex.Replace(name,@"\s*\("," (");name=Regex.Replace(name,@"\s+\+","+");
        name=Regex.Replace(name,@"\b(Note|Ace|Core|Grand|Mega|Mini|Pocket|Young|Wide|Buddy|Quantum|Jump|Trend|Star|Folder|Feel|Prevail|Stratosphere|Express|Exhibit|XCover|Tab|Fold|Flip)(\d)","$1 $2",RegexOptions.IgnoreCase);
        name=Regex.Replace(name,@"\b(Note) II\b","$1 2",RegexOptions.IgnoreCase);
        name=Regex.Replace(name,@"\bTabS","Tab S",RegexOptions.IgnoreCase);name=Regex.Replace(name,@"\bTabE","Tab E",RegexOptions.IgnoreCase);name=Regex.Replace(name,@"\bTap Pro","Tab Pro",RegexOptions.IgnoreCase);
        name=Regex.Replace(name,@"\b(edge|ultra|mini|duos|plus|view|win)\b",m=>CultureInfo.InvariantCulture.TextInfo.ToTitleCase(m.Value.ToLowerInvariant()),RegexOptions.IgnoreCase);
        name=Regex.Replace(name,@"\bXcover\s*","XCover ",RegexOptions.IgnoreCase);name=name.Replace("Grand-Max","Grand Max").Replace("Neo+","Neo Plus").Replace("FieldPro","Field Pro");
        // Connectivity and carrier listings of the same flagship share one entry.
        if(Regex.IsMatch(name,@"^Galaxy (S(?:2[0-9])|Note (?:10|20)|Z (?:Fold|Flip))"))name=Regex.Replace(name,@"\s+(5G|LTE|UW)\b","",RegexOptions.IgnoreCase);
        name=Regex.Replace(name,@"\s+(Olympic Games Edition|Google Play Edition|Dual SIM)$","",RegexOptions.IgnoreCase);
        if(name=="J1 Mini Prime")name="Galaxy J1 Mini Prime";
        if(name.Contains("三星")){var match=Regex.Match(name,@"W\d+(?: Flip)?");if(match.Success)name="Samsung "+match.Value;}
        return Regex.Replace(name,@"\s+"," ").Trim();
    }
    static bool NamedDevice(string name){return !Regex.IsMatch(name,@"^(?:SM-|GT-|SCH-|SHV-|SHW-|SGH-|SPH-|EK-)",RegexOptions.IgnoreCase)&&!Regex.IsMatch(name,@"Chromebook|Watch|Gear Live|Interactive Display|ProXpress|Homesync|^WAF|Galaxy XR",RegexOptions.IgnoreCase);}
    public static void Load(){
        var catalog=new Dictionary<string,Device>(StringComparer.OrdinalIgnoreCase);
        using(var input=Assembly.GetExecutingAssembly().GetManifestResourceStream("devices.tsv")){
            if(input==null)throw new IOException("The bundled device catalog is missing.");using(var reader=new StreamReader(input)){string line;while((line=reader.ReadLine())!=null){var p=line.Split(new[]{'\t'});if(p.Length<3)continue;bool apple=p[0]=="Apple";string name=apple?p[1]:Normalize(p[1]);if(!apple&&!NamedDevice(name))continue;
                // Ignore spacing/case variants, while retaining all internal hardware aliases for import matching.
                string key=(apple?"apple:":"samsung:")+Regex.Replace(apple?name:Regex.Replace(name,@"^(Galaxy|Samsung) ",""),@"[\s\-\(\)\"",]","");Device device;
                if(!catalog.TryGetValue(key,out device)){device=new Device{Make=apple?"Apple":"samsung",Name=name,Model=apple?name:Regex.Replace(name,@"^(Galaxy|Samsung) ",""),Hardware=p[2]};catalog.Add(key,device);}
                foreach(var alias in new[]{p[1],p[2]})if(!device.Aliases.Contains(alias))device.Aliases.Add(alias);
                if(p[2].StartsWith("SM-",StringComparison.OrdinalIgnoreCase)&&p[2].EndsWith("B",StringComparison.OrdinalIgnoreCase))device.Hardware=p[2];
            }}
        }
        if(catalog.Count==0)throw new IOException("The bundled device catalog is empty.");
        All=catalog.Values.OrderBy(d=>d.Make=="Apple"?0:d.Name.StartsWith("Galaxy S2")?1:d.Name.StartsWith("Galaxy Z")?2:3).ThenByDescending(d=>d.Make=="Apple"?0:Generation(d.Name)).ThenBy(d=>d.Name,StringComparer.OrdinalIgnoreCase).ToList();
    }
    static int Generation(string s){var match=Regex.Match(s,@"(?:Galaxy S|Galaxy Z (?:Fold|Flip) )(\d+)");int n;return match.Success&&int.TryParse(match.Groups[1].Value,out n)?n:0;}
    public string LensMake{get{return Make=="Apple"?"Apple":"Samsung";}}
    public string LensModel{get{return Name+" back main camera";}}
    public static string NewSerial(){return "OS"+Guid.NewGuid().ToString("N").Substring(0,12).ToUpperInvariant();}
    public static string GenerateSoftware(string make,string model){
        var d=Find(model);byte[] random=new byte[8];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(random);
        if((d!=null&&d.Make=="Apple")||string.Equals(make,"Apple",StringComparison.OrdinalIgnoreCase)){
            int gen=18;var match=Regex.Match(model??"",@"iPhone (\d+)");if(match.Success)gen=Math.Min(26,Math.Max(10,int.Parse(match.Groups[1].Value)+8));if((model??"").Contains(" X"))gen=16;
            return gen+"."+(random[0]%5)+"."+(random[1]%4)+" ("+(gen+4)+(char)('A'+random[2]%8)+(100+random[3]*3)+")";
        }
        string prefix=d==null?"":Regex.Replace(d.Hardware??"",@"^(SM-|GT-)","",RegexOptions.IgnoreCase);prefix=Regex.Replace(prefix,@"[^A-Za-z0-9]","").ToUpperInvariant();
        if(prefix.Length<4)prefix=Regex.Replace(model??"",@"[^A-Za-z0-9]","").ToUpperInvariant();if(prefix.Length<4)prefix="OS01";if(prefix.Length>5)prefix=prefix.Substring(0,5);
        string value=prefix+"XX"+(random[0]%2==0?"U":"S")+(1+random[1]%9)+(char)('A'+random[2]%5)+(char)('A'+random[3]%26)+(char)('A'+random[4]%12)+(char)('1'+random[5]%9);
        // Synthetic sample build only: no real firmware lookup or device identity is involved.
        return value;
    }
}
}
