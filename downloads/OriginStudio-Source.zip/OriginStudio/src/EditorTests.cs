using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace OriginStudio {
static class EditorTests {
    static int count;
    static void Check(bool ok,string message){if(!ok)throw new Exception("FAILED: "+message);count++;Console.WriteLine("PASS: "+message);}
    static Bitmap Solid(int w,int h,Color color){var b=new Bitmap(w,h);using(var g=Graphics.FromImage(b))g.Clear(color);return b;}
    static bool Near(int a,int b,int tolerance=3){return Math.Abs(a-b)<=tolerance;}
    static void Call(object instance,string method,params object[] args){instance.GetType().GetMethod(method,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(instance,args);}
    [STAThread] static void Main(string[] args){
        Device.Load();Check(Device.All.Select(d=>d.Make+":"+d.Model.ToLowerInvariant()).Distinct().Count()==Device.All.Count,"Device models are unique ignoring case");
        foreach(string name in new[]{"S26","S26+","S26 Ultra","S25","S25+","S25 Edge","S25 Ultra"})Check(Device.All.Count(d=>d.Make=="samsung"&&d.Model==name)==1,"Exactly one Samsung "+name);
        Check(Device.All.Where(d=>d.Make=="samsung").All(d=>!d.Model.StartsWith("SM-")&&!d.Model.StartsWith("GT-")),"Picker contains friendly names, not hardware-only codes");Check(Device.Find("SM-S928B").Model=="S24 Ultra","Imported regional hardware code still resolves to its friendly preset");
        var builds=new HashSet<string>();for(int i=0;i<100;i++)builds.Add(Device.GenerateSoftware("samsung","S26"));Check(builds.Count==100&&builds.All(s=>s.StartsWith("S942BXX")&&s!="S942BXXS4BZIG"),"Generated Samsung software varies and does not reproduce the supplied real build");Check(Device.GenerateSoftware("Apple","iPhone X").StartsWith("16."),"Apple generation uses an iOS-style value for iPhone X");Check(Device.NewSerial()!=Device.NewSerial(),"Serial generation produces fresh sample identifiers");
        using(var c=new EditorCanvas()){
            c.Size=new Size(464,364);c.Replace(Solid(200,150,Color.Blue));c.AddImage(Solid(100,100,Color.Red),"Red image");var l=c.ActiveLayer;Check(l.Kind=="Image"&&Near((int)l.Bounds.X,50),"Imported image becomes an independently positioned layer");
            using(var b=c.Render(200,150)){Check(b.GetPixel(100,75).R==255&&b.GetPixel(2,2).B==255,"Image layers composite over the background");}
            c.Remember();l.Opacity=.5f;c.Commit();using(var b=c.Render(200,150))Check(Near(b.GetPixel(100,75).R,128)&&Near(b.GetPixel(100,75).B,127),"Layer opacity mixes source and destination pixels");c.Undo();Check(c.ActiveLayer.Opacity==1,"Undo restores per-layer opacity");l=c.ActiveLayer;
            c.SetMask(Pixels.ShapeMask(100,100,"Ellipse"));using(var b=c.Render(200,150))Check(b.GetPixel(51,26).B==255&&b.GetPixel(100,75).R==255,"Ellipse mask hides corners and reveals the photo center");c.Undo();Check(c.ActiveLayer.Mask==null,"Undo removes a mask without changing the source pixels");c.Redo();Check(c.ActiveLayer.Mask!=null,"Redo restores the mask");
            c.StartMask(true);c.Tool="Mask hide";c.BrushSize=30;c.MaskSoftness=0;c.Fit();
            Call(c,"OnMouseDown",new MouseEventArgs(MouseButtons.Left,1,c.Width/2,c.Height/2,0));Call(c,"OnMouseUp",new MouseEventArgs(MouseButtons.Left,1,c.Width/2,c.Height/2,0));
            using(var b=c.Render(200,150))Check(b.GetPixel(100,75).B>245,"Mask-hide brush removes pixels at the actual pointer position");c.Undo();using(var b=c.Render(200,150))Check(b.GetPixel(100,75).R>245,"Undo restores a painted mask stroke");c.Redo();c.Tool="Mask reveal";Call(c,"OnMouseDown",new MouseEventArgs(MouseButtons.Left,1,c.Width/2,c.Height/2,0));Call(c,"OnMouseUp",new MouseEventArgs(MouseButtons.Left,1,c.Width/2,c.Height/2,0));using(var b=c.Render(200,150))Check(b.GetPixel(100,75).R>245,"Reveal brush restores hidden image pixels");
            c.ActiveLayer.Locked=true;int layerCount=c.Layers.Count;c.DeleteSelected();Check(c.Layers.Count==layerCount,"Locked layers cannot be deleted");c.ActiveLayer.Locked=false;c.ActiveLayer.Adjustments.Saturation=0;using(var b=c.Render(200,150))Check(Near(b.GetPixel(100,75).R,b.GetPixel(100,75).G),"Per-image colour adjustment affects the selected image");Check(c.ActiveLayer.Pixels.GetPixel(50,50).R==255,"Colour edits preserve original layer pixels");
            c.Remember();c.ActiveLayer.Rotation=45;c.ActiveLayer.FlipX=true;c.ActiveLayer.Name="Masked photo";c.ActiveLayer.OutlineWidth=2;c.ActiveLayer.ShadowOpacity=.4f;c.ActiveLayer.Locked=true;c.Commit();
            var dto=ProjectData.Create(c,new Metadata(),"Layers.png");string json=new JavaScriptSerializer{MaxJsonLength=int.MaxValue}.Serialize(dto);File.WriteAllText(Path.Combine(args[0],"layers.origin"),json);var restored=new JavaScriptSerializer{MaxJsonLength=int.MaxValue}.Deserialize<ProjectData>(json);using(var other=new EditorCanvas()){restored.Apply(other);var r=other.Layers[0];Check(r.Pixels!=null&&r.Mask!=null&&r.Locked&&r.Rotation==45&&r.FlipX&&r.Adjustments.Saturation==0&&r.ShadowOpacity==.4f,"Project round-trip retains image pixels, mask, colour settings, locks, transforms and effects");using(var a=c.Render(200,150))using(var b=other.Render(200,150))Check(Pixels.Read(a).SequenceEqual(Pixels.Read(b)),"Reopened project renders exactly the same pixels");}
            restored.Layers[0].Opacity=float.NaN;bool rejected=false;try{restored.Apply(c);}catch(IOException){rejected=true;}Check(rejected&&c.ActiveLayer.Name=="Masked photo","Invalid project values are rejected before replacing the current document");
        }
        using(var c=new EditorCanvas()){
            c.Replace(Solid(100,100,Color.Transparent));c.BackgroundVisible=false;c.Layers.Add(new Layer{Kind="Ellipse",Name="Shape",Fill=true,Color=Color.White,Bounds=new RectangleF(10,10,80,80)});c.AddImage(Solid(100,100,Color.Red),"Photo");c.ActiveLayer.ClipToBelow=true;
            using(var b=c.Render(100,100))Check(b.GetPixel(0,0).A==0&&b.GetPixel(50,50).R==255,"Clip below fits a photo into the alpha shape of the preceding layer");c.Layers[0].Visible=false;using(var b=c.Render(100,100))Check(b.GetPixel(50,50).A==0,"Hidden clipping source hides the clipped photo");
        }
        foreach(string mode in new[]{"Multiply","Screen","Overlay","Darken","Lighten","Difference"})using(var c=new EditorCanvas()){
            c.Replace(Solid(10,10,Color.FromArgb(128,128,128)));c.AddImage(Solid(10,10,Color.FromArgb(64,64,64)),"Blend");c.ActiveLayer.Blend=mode;using(var b=c.Render(10,10)){int expected=mode=="Multiply"?32:mode=="Screen"?160:mode=="Overlay"?65:mode=="Darken"?64:mode=="Lighten"?128:64;Check(Near(b.GetPixel(5,5).R,expected),mode+" follows its blend formula");}
        }
        using(var c=new EditorCanvas()){
            c.Replace(Solid(100,100,Color.Red));c.Layers.Add(new Layer{Kind="Adjustment",Name="B&W",Bounds=new RectangleF(0,0,100,100),Adjustments=new ColorSettings{Saturation=0}});c.Selected=0;var mask=Pixels.SolidMask(100,100,false);using(var g=Graphics.FromImage(mask))g.FillRectangle(Brushes.White,0,0,50,100);c.SetMask(mask);
            using(var b=c.Render(100,100))Check(Near(b.GetPixel(25,50).R,b.GetPixel(25,50).G)&&b.GetPixel(75,50).R==255&&b.GetPixel(75,50).G==0,"Adjustment-layer mask limits colour changes to the revealed area");
            c.AddImage(Solid(10,10,Color.Green),"On top");using(var b=c.Render(100,100))Check(b.GetPixel(50,50).G>100&&b.GetPixel(50,50).R==0,"Adjustment layer leaves layers above it unaffected");
            c.ResizeDocument(140,140);Check(c.Layers.Count==3&&!c.BackgroundVisible&&c.Image.Width==140,"Canvas resizing preserves original photo and existing layers");using(var b=c.Render(140,140))Check(b.GetPixel(0,0).A==0,"Canvas expansion introduces transparent space");c.Undo();Check(c.Image.Width==100&&c.Layers.Count==2,"Undo restores pre-resize canvas and layer stack");
        }
        using(var b=Solid(20,10,Color.Transparent)){
            using(var g=Graphics.FromImage(b))g.FillRectangle(Brushes.White,0,0,10,10);using(var alpha=Pixels.FromMask(b,"Alpha"))Check(alpha.GetPixel(2,2).R==255&&alpha.GetPixel(15,2).R==0,"Image-alpha masks preserve transparent silhouettes");
            using(var light=Pixels.FromMask(b,"Luminance"))Check(light.GetPixel(2,2).R==255&&light.GetPixel(15,2).R==0,"Luminance masks account for source transparency");b.SetPixel(10,5,Color.Black);using(var dark=Pixels.FromMask(b,"Dark silhouette"))Check(dark.GetPixel(2,2).R==0&&dark.GetPixel(15,2).R==0&&dark.GetPixel(10,5).R==255,"Dark silhouette masks reveal black areas while preserving transparency");
        }
        using(var b=Solid(20,20,Color.White)){using(var g=Graphics.FromImage(b))g.FillRectangle(Brushes.Red,5,5,10,10);using(var mask=RasterFilters.RemoveColor(b,Color.White,10,5))Check(mask.GetPixel(0,0).R==0&&mask.GetPixel(10,10).R==255,"Colour removal builds a reversible background mask");}
        using(var b=Pixels.SolidMask(20,20,false)){using(var g=Graphics.FromImage(b))g.FillRectangle(Brushes.White,5,5,10,10);using(var feather=Pixels.Feather(b,3))Check(feather.GetPixel(4,10).R>0&&feather.GetPixel(4,10).R<255,"Mask feathering creates partial coverage at an edge");}
        using(var b=Solid(20,20,Color.Black)){b.SetPixel(10,10,Color.White);RasterFilters.Blur(b,2);Check(b.GetPixel(10,10).R<255&&b.GetPixel(9,10).R>0,"Blur spreads a bright pixel into its neighbors");}
        using(var b=Solid(10,10,Color.FromArgb(100,100,100))){b.SetPixel(5,5,Color.FromArgb(150,150,150));RasterFilters.Apply(b,new ColorSettings{Sharpen=1},1);Check(b.GetPixel(5,5).R>150,"Sharpen increases local contrast");}
        using(var b=RasterFilters.Gradient(100,10,Color.Red,Color.Blue,0,false))Check(b.GetPixel(5,5).R>b.GetPixel(5,5).B&&b.GetPixel(95,5).B>b.GetPixel(95,5).R,"Gradient layer transitions between chosen colours");
        using(var c=new EditorCanvas()){
            c.Replace(Solid(30,30,Color.White));var old=new ProjectData{Version=1,Pixels=Convert.ToBase64String(MainWindow.Encode(c.Image,true,100)),Brightness=.1f,Contrast=1.2f,Saturation=.8f,Layers=new List<LayerData>{new LayerData{Kind="Rectangle",Name="Old shape",Color=Color.Red.ToArgb(),Bounds=new[]{2f,2f,10f,10f},Width=3,Opacity=1,Fill=true,Visible=true,Points=new float[0]}}};old.Apply(c);Check(c.Layers.Count==1&&c.BackgroundVisible&&c.Brightness==.1f&&c.Contrast==1.2f,"Version 1.0 projects remain readable with their original adjustments");
        }
        Console.WriteLine("Completed "+count+" editor checks. "+Device.All.Count(d=>d.Make=="Apple")+" iPhones / "+Device.All.Count(d=>d.Make=="samsung")+" named Samsung devices.");File.WriteAllText(Path.Combine(args[0],"editor-test-results.txt"),count+" checks passed.");
    }
}
}
