using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace OriginStudio {
public sealed class PinMap : Control {
    double pinLat=29.3759,pinLon=47.9774;public double Latitude{get{return pinLat;}set{pinLat=value;}}public double Longitude{get{return pinLon;}set{pinLon=value;}}public double CenterLat=29.3759,CenterLon=47.9774;public int Zoom=12;
    public Action<double,double> Pinned;public Action<string> Message;
    readonly Dictionary<string,Bitmap> tiles=new Dictionary<string,Bitmap>();readonly HashSet<string> loading=new HashSet<string>();readonly SemaphoreSlim slots=new SemaphoreSlim(4);
    Point down;double startX,startY;bool dragging,moved;
    public PinMap(){DoubleBuffered=true;BackColor=Theme.Inset;Dock=DockStyle.Fill;SetStyle(ControlStyles.ResizeRedraw,true);}
    static double WorldX(double lon,int z){return(lon+180)/360*(256*(1<<z));}
    static double WorldY(double lat,int z){lat=Math.Max(-85.05112878,Math.Min(85.05112878,lat));double rad=lat*Math.PI/180;return(1-Math.Log(Math.Tan(rad)+1/Math.Cos(rad))/Math.PI)/2*(256*(1<<z));}
    static double LatFromY(double y,int z){double n=Math.PI-2*Math.PI*y/(256*(1<<z));return Math.Atan(Math.Sinh(n))*180/Math.PI;}
    static double LonFromX(double x,int z){return x/(256*(1<<z))*360-180;}
    public void SetPin(double lat,double lon,bool center=true){Latitude=lat;Longitude=lon;if(center){CenterLat=lat;CenterLon=lon;}Invalidate();if(Pinned!=null)Pinned(lat,lon);}
    public void ChangeZoom(int delta){Zoom=Math.Max(2,Math.Min(19,Zoom+delta));Invalidate();}
    protected override void OnPaint(PaintEventArgs e){
        base.OnPaint(e);var g=e.Graphics;g.Clear(BackColor);double cx=WorldX(CenterLon,Zoom),cy=WorldY(CenterLat,Zoom);double ox=cx-Width/2.0,oy=cy-Height/2.0;int n=1<<Zoom;
        int left=(int)Math.Floor(ox/256),top=(int)Math.Floor(oy/256),right=(int)Math.Floor((ox+Width)/256),bottom=(int)Math.Floor((oy+Height)/256);
        for(int y=top;y<=bottom;y++)for(int x=left;x<=right;x++){
            int xx=((x%n)+n)%n;if(y<0||y>=n)continue;string key=Zoom+"/"+xx+"/"+y;var rect=new Rectangle((int)(x*256-ox),(int)(y*256-oy),256,256);
            Bitmap tile;if(tiles.TryGetValue(key,out tile))g.DrawImage(tile,rect);else {using(var brush=new SolidBrush(Color.FromArgb(36,38,44)))g.FillRectangle(brush,rect);using(var pen=new Pen(Theme.Line))g.DrawRectangle(pen,rect);if(!loading.Contains(key))LoadTile(key);}
        }
        float px=(float)(WorldX(Longitude,Zoom)-ox),py=(float)(WorldY(Latitude,Zoom)-oy);g.SmoothingMode=SmoothingMode.AntiAlias;
        using(var b=new SolidBrush(Color.FromArgb(55,101,70,220)))g.FillEllipse(b,px-22,py-22,44,44);
        using(var b=new SolidBrush(Theme.Accent))g.FillEllipse(b,px-9,py-9,18,18);using(var p=new Pen(Color.White,3))g.DrawEllipse(p,px-9,py-9,18,18);
        using(var b=new SolidBrush(Color.FromArgb(220,23,24,28)))g.FillRectangle(b,Width-200,Height-26,200,26);using(var b=new SolidBrush(Theme.Muted))g.DrawString("© OpenStreetMap contributors",Theme.Small,b,Width-194,Height-20);
    }
    async void LoadTile(string key){
        loading.Add(key);await slots.WaitAsync();Bitmap b=null;
        try{
            byte[] data=await Task.Run(()=>{
                string cache=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OriginStudio","MapCache",key.Replace('/','_')+".png");
                if(File.Exists(cache)&&(DateTime.UtcNow-File.GetLastWriteTimeUtc(cache)).TotalDays<7)return File.ReadAllBytes(cache);
                byte[] bytes=Network.Get("https://tile.openstreetmap.org/"+key+".png");Directory.CreateDirectory(Path.GetDirectoryName(cache));File.WriteAllBytes(cache,bytes);return bytes;
            });
            using(var ms=new MemoryStream(data))using(var image=Image.FromStream(ms))b=new Bitmap(image);
        }catch(Exception ex){if(Message!=null&&!IsDisposed)Message("Map tiles unavailable. Coordinates and Google Maps links still work. "+ex.Message);}finally{slots.Release();}
        if(IsDisposed){if(b!=null)b.Dispose();return;}loading.Remove(key);if(b!=null){tiles[key]=b;if(tiles.Count>160){string first=tiles.Keys.First();tiles[first].Dispose();tiles.Remove(first);}}Invalidate();
    }
    protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(e.Button!=MouseButtons.Left)return;down=e.Location;startX=WorldX(CenterLon,Zoom);startY=WorldY(CenterLat,Zoom);dragging=true;moved=false;Capture=true;Cursor=Cursors.SizeAll;}
    protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);if(!dragging)return;int dx=e.X-down.X,dy=e.Y-down.Y;if(Math.Abs(dx)+Math.Abs(dy)>5)moved=true;if(moved){CenterLon=LonFromX(startX-dx,Zoom);CenterLon=((CenterLon+180)%360+360)%360-180;CenterLat=LatFromY(startY-dy,Zoom);Invalidate();}}
    protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);if(!dragging)return;if(!moved){double x=WorldX(CenterLon,Zoom)+e.X-Width/2.0,y=WorldY(CenterLat,Zoom)+e.Y-Height/2.0;SetPin(LatFromY(y,Zoom),((LonFromX(x,Zoom)+180)%360+360)%360-180,false);}dragging=false;Capture=false;Cursor=Cursors.Cross;}
    protected override void OnMouseWheel(MouseEventArgs e){base.OnMouseWheel(e);ChangeZoom(e.Delta>0?1:-1);}
    protected override void Dispose(bool disposing){if(disposing)foreach(var b in tiles.Values)b.Dispose();base.Dispose(disposing);}
}
public static class Network {
    static readonly object geoLock=new object();static DateTime lastGeo=DateTime.MinValue;
    public static byte[] Get(string url,bool geocoder=false){
        if(geocoder)lock(geoLock){double delay=1100-(DateTime.UtcNow-lastGeo).TotalMilliseconds;if(delay>0)Thread.Sleep((int)delay);lastGeo=DateTime.UtcNow;}
        ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;
        var request=(HttpWebRequest)WebRequest.Create(url);request.UserAgent="OriginStudio/1.0 (Windows photo editor)";request.Timeout=10000;request.ReadWriteTimeout=10000;request.AutomaticDecompression=DecompressionMethods.GZip|DecompressionMethods.Deflate;
        using(var response=request.GetResponse())using(var input=response.GetResponseStream())using(var ms=new MemoryStream()){input.CopyTo(ms);if(ms.Length>12000000)throw new IOException("Map response is too large.");return ms.ToArray();}
    }
    public static bool ParseLocation(string text,out double lat,out double lon){
        lat=lon=0;text=Uri.UnescapeDataString(text??"");
        string[] patterns={@"!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)",@"!2d(-?\d+(?:\.\d+)?)!3d(-?\d+(?:\.\d+)?)",@"(?:q=|query=|ll=)(-?\d+(?:\.\d+)?)[,\s]+(-?\d+(?:\.\d+)?)",@"@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)",@"^\s*(-?\d+(?:\.\d+)?)\s*[,;]\s*(-?\d+(?:\.\d+)?)\s*$"};
        for(int i=0;i<patterns.Length;i++){var m=Regex.Match(text,patterns[i]);if(!m.Success)continue;double a,b;if(double.TryParse(m.Groups[1].Value,NumberStyles.Float,CultureInfo.InvariantCulture,out a)&&double.TryParse(m.Groups[2].Value,NumberStyles.Float,CultureInfo.InvariantCulture,out b)){lat=i==1?b:a;lon=i==1?a:b;return Math.Abs(lat)<=90&&Math.Abs(lon)<=180;}}return false;
    }
    public static string ResolveGoogleLink(string url){
        Uri u;if(!Uri.TryCreate(url,UriKind.Absolute,out u)||u.Scheme!="https"||!(u.Host=="maps.app.goo.gl"||u.Host=="goo.gl"||u.Host=="www.google.com"||u.Host=="maps.google.com"||u.Host=="google.com"))throw new FormatException("Paste a Google Maps link or latitude, longitude.");
        var req=(HttpWebRequest)WebRequest.Create(u);req.UserAgent="OriginStudio/1.0";req.Timeout=10000;req.AllowAutoRedirect=true;using(var response=req.GetResponse())return response.ResponseUri.ToString();
    }
}
public sealed class LocationForm : Form {
    public double Latitude{get;set;}public double Longitude{get;set;}public string Place="",City="",PlaceRegion="",Country="";
    PinMap map;TextBox lat,lon,search;Label place,status;int revision;bool updating;Button use;
    public LocationForm(double initialLat,double initialLon,string initialPlace){
        Theme.Style(this);Text="Location studio · Origin Studio";Size=new Size(980,700);MinimumSize=new Size(760,560);Latitude=initialLat;Longitude=initialLon;Place=initialPlace;
        var top=new FlowLayoutPanel{Dock=DockStyle.Top,Height=58,Padding=new Padding(12),BackColor=Theme.Panel,WrapContents=false};
        search=Theme.Edit();search.Width=500;search.Text="";top.Controls.Add(search);var find=Theme.Button("Search / import",()=>Search());find.Width=135;top.Controls.Add(find);var gm=Theme.Button("Google Maps ↗",()=>OpenGoogle());gm.Width=135;top.Controls.Add(gm);Controls.Add(top);
        map=new PinMap{Latitude=Latitude,Longitude=Longitude,CenterLat=Latitude,CenterLon=Longitude};map.Pinned=(a,b)=>Pin(a,b);map.Message=s=>{if(!IsDisposed)status.Text=s;};Controls.Add(map);map.BringToFront();
        var bottom=new Panel{Dock=DockStyle.Bottom,Height=140,BackColor=Theme.Panel};Controls.Add(bottom);bottom.BringToFront();
        var hint=Theme.Label("Click to pin · Drag to pan · Scroll to zoom · Search a place or paste a Google Maps link");hint.Location=new Point(14,8);bottom.Controls.Add(hint);
        lat=Theme.Edit(Latitude.ToString("F7",CultureInfo.InvariantCulture));lon=Theme.Edit(Longitude.ToString("F7",CultureInfo.InvariantCulture));lat.SetBounds(14,37,170,27);lon.SetBounds(194,37,170,27);bottom.Controls.Add(lat);bottom.Controls.Add(lon);
        var apply=Theme.Button("Set coordinates",()=>{double a,b;if(double.TryParse(lat.Text,NumberStyles.Float,CultureInfo.InvariantCulture,out a)&&double.TryParse(lon.Text,NumberStyles.Float,CultureInfo.InvariantCulture,out b)&&Math.Abs(a)<=90&&Math.Abs(b)<=180)map.SetPin(a,b);else status.Text="Latitude -90…90, longitude -180…180.";});apply.SetBounds(376,35,135,32);bottom.Controls.Add(apply);
        place=Theme.Label(Place,true);place.AutoSize=false;place.SetBounds(14,73,700,23);bottom.Controls.Add(place);
        status=Theme.Label("Search uses OpenStreetMap. Google Maps opens in your browser.");status.AutoSize=false;status.SetBounds(14,104,740,24);bottom.Controls.Add(status);
        use=Theme.Button("Use this location",()=>{Latitude=map.Latitude;Longitude=map.Longitude;DialogResult=DialogResult.OK;Close();},true);use.Anchor=AnchorStyles.Right|AnchorStyles.Bottom;use.SetBounds(Width-200,82,160,35);bottom.Controls.Add(use);
        var zoom=new FlowLayoutPanel{Dock=DockStyle.Right,Width=46,Padding=new Padding(2),BackColor=Theme.Panel};var plus=Theme.Button("+",()=>map.ChangeZoom(1));plus.Width=34;var minus=Theme.Button("−",()=>map.ChangeZoom(-1));minus.Width=34;zoom.Controls.Add(plus);zoom.Controls.Add(minus);Controls.Add(zoom);zoom.BringToFront();
        search.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;Search();}};
    }
    void OpenGoogle(){try{System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://www.google.com/maps/search/?api=1&query="+map.Latitude.ToString(CultureInfo.InvariantCulture)+","+map.Longitude.ToString(CultureInfo.InvariantCulture)){UseShellExecute=true});}catch(Exception ex){status.Text=ex.Message;}}
    void Pin(double a,double b){Latitude=a;Longitude=b;lat.Text=a.ToString("F7",CultureInfo.InvariantCulture);lon.Text=b.ToString("F7",CultureInfo.InvariantCulture);Place=a.ToString("F5",CultureInfo.InvariantCulture)+", "+b.ToString("F5",CultureInfo.InvariantCulture);City=PlaceRegion=Country="";place.Text=Place;Reverse(a,b);}
    async void Reverse(double a,double b){
        int ticket=++revision;status.Text="Resolving place name…";
        try{await Task.Delay(650);if(ticket!=revision||IsDisposed)return;var bytes=await Task.Run(()=>Network.Get("https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat="+a.ToString(CultureInfo.InvariantCulture)+"&lon="+b.ToString(CultureInfo.InvariantCulture)+"&zoom=18&addressdetails=1",true));
            if(IsDisposed||ticket!=revision)return;var data=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(System.Text.Encoding.UTF8.GetString(bytes));object val;if(data.TryGetValue("display_name",out val))Place=val.ToString();if(data.TryGetValue("address",out val)){var addr=val as Dictionary<string,object>;if(addr!=null){City=First(addr,"city","town","village","municipality");PlaceRegion=First(addr,"state","region","province");Country=First(addr,"country");}}place.Text=Place;status.Text="Pin ready · "+a.ToString("F7",CultureInfo.InvariantCulture)+", "+b.ToString("F7",CultureInfo.InvariantCulture);
        }catch(Exception){if(!IsDisposed&&ticket==revision)status.Text="Pin ready. Place-name lookup unavailable; exact GPS coordinates will be saved.";}
    }
    static string First(Dictionary<string,object>d,params string[] keys){foreach(var k in keys){object v;if(d.TryGetValue(k,out v))return v.ToString();}return "";}
    async void Search(){
        if(updating)return;updating=true;status.Text="Finding location…";
        try{string q=search.Text.Trim();double a,b;if(Network.ParseLocation(q,out a,out b)){map.SetPin(a,b);return;}
            if(q.StartsWith("https://",StringComparison.OrdinalIgnoreCase)){string resolved=await Task.Run(()=>Network.ResolveGoogleLink(q));if(!Network.ParseLocation(resolved,out a,out b))throw new FormatException("This link has no readable pin coordinates. In Google Maps, right-click a point and copy its latitude, longitude.");map.SetPin(a,b);return;}
            if(q.Length<3)throw new FormatException("Enter a place, an address, coordinates or a Google Maps link.");
            var bytes=await Task.Run(()=>Network.Get("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q="+Uri.EscapeDataString(q),true));if(IsDisposed)return;
            var rows=new JavaScriptSerializer().Deserialize<List<Dictionary<string,object>>>(System.Text.Encoding.UTF8.GetString(bytes));if(rows.Count==0)throw new FormatException("No matching place. Try a city name or exact coordinates.");map.Zoom=15;map.SetPin(double.Parse(rows[0]["lat"].ToString(),CultureInfo.InvariantCulture),double.Parse(rows[0]["lon"].ToString(),CultureInfo.InvariantCulture));
        }catch(Exception ex){if(!IsDisposed)status.Text=ex.Message;}finally{updating=false;}
    }
}
}
