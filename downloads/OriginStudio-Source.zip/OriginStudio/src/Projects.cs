using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;

namespace OriginStudio {
public sealed class LayerData {
    public string Kind,Name,Text,Blend="Normal",Pixels,Mask,FontFamily="Segoe UI";
    public float[] Points,Bounds;
    public int Color,OutlineColor=System.Drawing.Color.White.ToArgb();
    public float Width,Opacity,Rotation,ShadowOpacity,ShadowDistance=12,OutlineWidth;
    public bool Fill,Visible,Locked,ClipToBelow,FlipX,FlipY,MaskEnabled=true,Bold=true,Italic;
    public ColorSettings Adjustments=new ColorSettings();
}
public sealed class ProjectData {
    public int Version=2,Selected=-1;
    public string Name,Pixels;
    public List<LayerData> Layers;
    public Metadata Metadata;
    public float Brightness,Contrast=1,Saturation=1;
    public bool BackgroundVisible=true;
    public ColorSettings Adjustments=new ColorSettings();
    static string Encode(Bitmap bitmap){return bitmap==null?null:Convert.ToBase64String(MainWindow.Encode(bitmap,true,100));}
    public static ProjectData Create(EditorCanvas c,Metadata m,string name){return new ProjectData{Name=name,Pixels=Encode(c.Image),Metadata=m,Selected=c.Selected,BackgroundVisible=c.BackgroundVisible,Adjustments=c.BackgroundAdjustments.Clone(),Brightness=c.Brightness,Contrast=c.Contrast,Saturation=c.Saturation,Layers=c.Layers.Select(l=>new LayerData{Kind=l.Kind,Name=l.Name,Text=l.Text,Blend=l.Blend,Pixels=Encode(l.Pixels),Mask=Encode(l.Mask),FontFamily=l.FontFamily,Bold=l.Bold,Italic=l.Italic,ShadowOpacity=l.ShadowOpacity,ShadowDistance=l.ShadowDistance,OutlineWidth=l.OutlineWidth,OutlineColor=l.OutlineColor.ToArgb(),Adjustments=l.Adjustments.Clone(),Points=l.Points.SelectMany(p=>new[]{p.X,p.Y}).ToArray(),Bounds=new[]{l.Bounds.X,l.Bounds.Y,l.Bounds.Width,l.Bounds.Height},Color=l.Color.ToArgb(),Width=l.Width,Opacity=l.Opacity,Fill=l.Fill,Visible=l.Visible,Locked=l.Locked,ClipToBelow=l.ClipToBelow,Rotation=l.Rotation,FlipX=l.FlipX,FlipY=l.FlipY,MaskEnabled=l.MaskEnabled}).ToList()};}
    static void Range(float number,float min,float max){if(float.IsNaN(number)||float.IsInfinity(number)||number<min||number>max)throw new IOException("The project contains an invalid editing value.");}
    public static void ValidateColors(ColorSettings s){
        if(s==null)throw new IOException("Colour settings are missing.");foreach(var f in typeof(ColorSettings).GetFields())if(f.FieldType==typeof(float))Range((float)f.GetValue(s),-400,400);
        Range(s.Exposure,-4,4);Range(s.Gamma,.2f,3);Range(s.Contrast,0,2.5f);Range(s.Saturation,0,2.5f);Range(s.Red,0,2);Range(s.Green,0,2);Range(s.Blue,0,2);Range(s.Sepia,0,1);Range(s.Blur,0,30);Range(s.Sharpen,0,3);Range(s.Pixelate,0,80);
    }
    static Bitmap Decode(string text,List<Bitmap> owned,ref long total){
        if(string.IsNullOrEmpty(text))return null;using(var ms=new MemoryStream(Convert.FromBase64String(text)))using(var image=Image.FromStream(ms,true,true)){long count=(long)image.Width*image.Height;total+=count;if(count>120000000||total>200000000)throw new IOException("Project pixels exceed the memory limit (120 MP per image, 200 MP combined).");var bitmap=OriginStudio.Pixels.Copy(image);owned.Add(bitmap);return bitmap;}
    }
    public void Apply(EditorCanvas canvas){
        if((Version!=1&&Version!=2)||string.IsNullOrEmpty(Pixels))throw new IOException("Unsupported project version.");if(Layers!=null&&Layers.Count>500)throw new IOException("Use 500 layers or fewer.");
        var owned=new List<Bitmap>();var layers=new List<Layer>();long total=0;bool transferred=false;
        try{var image=Decode(Pixels,owned,ref total);var colors=Version==1?new ColorSettings{Brightness=Brightness,Contrast=Contrast,Saturation=Saturation}:Adjustments;ValidateColors(colors);
            foreach(var d in Layers??new List<LayerData>()){
                if(!new[]{"Image","Adjustment","Brush","Rectangle","Ellipse","Line","Text"}.Contains(d.Kind))throw new IOException("Unsupported layer type.");if(d.Bounds==null||d.Bounds.Length!=4)throw new IOException("Layer bounds are missing.");foreach(float n in d.Bounds)Range(n,-40000,40000);Range(d.Bounds[2],0,20000);Range(d.Bounds[3],0,20000);Range(d.Width,0,2000);Range(d.Opacity,0,1);Range(d.Rotation,-360,360);Range(d.ShadowOpacity,0,1);Range(d.ShadowDistance,-200,200);Range(d.OutlineWidth,0,25);ValidateColors(d.Adjustments);
                if(!new[]{"Normal","Multiply","Screen","Overlay","Darken","Lighten","Difference"}.Contains(d.Blend))throw new IOException("Unsupported blend mode.");
                var l=new Layer{Kind=d.Kind,Name=d.Name??d.Kind,Text=d.Text??"",Blend=d.Blend,FontFamily=d.FontFamily??"Segoe UI",Bold=d.Bold,Italic=d.Italic,ShadowOpacity=d.ShadowOpacity,ShadowDistance=d.ShadowDistance,OutlineWidth=d.OutlineWidth,OutlineColor=System.Drawing.Color.FromArgb(d.OutlineColor),Pixels=Decode(d.Pixels,owned,ref total),Mask=Decode(d.Mask,owned,ref total),Adjustments=d.Adjustments.Clone(),Bounds=new RectangleF(d.Bounds[0],d.Bounds[1],d.Bounds[2],d.Bounds[3]),Color=System.Drawing.Color.FromArgb(d.Color),Width=d.Width,Opacity=d.Opacity,Fill=d.Fill,Visible=d.Visible,Locked=d.Locked,ClipToBelow=d.ClipToBelow,Rotation=d.Rotation,FlipX=d.FlipX,FlipY=d.FlipY,MaskEnabled=d.MaskEnabled};
                if(l.Kind=="Image"&&l.Pixels==null)throw new IOException("Image layer pixels are missing.");var points=d.Points??new float[0];if(points.Length>2000000||points.Length%2!=0)throw new IOException("Invalid drawing points.");for(int i=0;i<points.Length;i+=2){Range(points[i],-40000,40000);Range(points[i+1],-40000,40000);l.Points.Add(new PointF(points[i],points[i+1]));}layers.Add(l);
            }
            canvas.Replace(image);foreach(var bitmap in owned)canvas.Own(bitmap);transferred=true;canvas.Layers=layers;canvas.BackgroundAdjustments=colors.Clone();canvas.BackgroundVisible=Version==1||BackgroundVisible;canvas.Selected=Math.Max(-1,Math.Min(layers.Count-1,Selected));canvas.Transformed=true;canvas.Commit();
        }finally{if(!transferred)foreach(var bitmap in owned)bitmap.Dispose();}
    }
}
}
