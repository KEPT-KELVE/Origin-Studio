using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace OriginStudio {
static class GuiTests {
    static int count;
    static void Check(bool ok,string name){if(!ok)throw new Exception("FAILED: "+name);count++;Console.WriteLine("PASS: "+name);}
    static T Get<T>(object o,string key){return(T)o.GetType().GetField(key,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(o);}
    static void Call(object o,string method,params object[] args){o.GetType().GetMethod(method,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(o,args);}
    [STAThread] static void Main(string[] args){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Device.Load();using(var w=new MainWindow()){
        w.Show();Application.DoEvents();var canvas=Get<EditorCanvas>(w,"canvas");var fields=Get<Dictionary<string,TextBox>>(w,"fields");
        Check(canvas.Image.Width==1600&&canvas.Image.Height==1050,"Native window loads bundled image");Check(canvas.Visible&&canvas.Width>350&&canvas.Height>250,"Native editor canvas is visible");
        w.Size=new Size(1200,720);Application.DoEvents();Check(canvas.Width>350&&canvas.Height>200,"Canvas remains usable on smaller screens");var dims=Get<Label>(w,"dimensionsLabel");Check(dims.Right<=dims.Parent.Width&&dims.Visible,"Dimensions label remains inside header");
        var presetList=Get<ListBox>(w,"presetList");var presetBrand=Get<ComboBox>(w,"presetBrand");var presetSearch=Get<TextBox>(w,"presetSearch");
        Check(presetList.Visible&&presetList.Height>=80,"Preset list remains visible without sidebar scrolling at 1200 x 720");
        presetBrand.SelectedItem="Apple";Check(presetList.Items.Count==54,"Sidebar Apple filter lists all bundled iPhone models");
        presetBrand.SelectedItem="Samsung";Check(presetList.Items.Count==Device.All.Count(d=>d.Make=="samsung"),"Sidebar Samsung filter lists deduplicated named devices");
        presetSearch.Text="S26";Check(presetList.Items.Count>0&&presetList.Items.Count<10&&presetList.Items.Cast<Device>().Any(d=>d.Name=="Galaxy S26"),"Sidebar search finds Galaxy S26 presets by name");
        string actualModel=fields["model"].Text;Check(actualModel=="S24 Ultra","Browsing presets keeps the loaded camera metadata intact");
        presetSearch.Text="";presetBrand.SelectedItem="Apple";var iphone=presetList.Items.Cast<Device>().First(d=>d.Name=="iPhone X");Call(w,"ApplyDevice",iphone);Check(fields["make"].Text=="Apple"&&fields["model"].Text=="iPhone X","Selecting a preset can apply its actual camera fields");
        Call(w,"QuickDevice","Galaxy S24 Ultra");
        Check(fields["model"].Text=="S24 Ultra"&&fields["make"].Text=="samsung","Samsung preset writes a friendly model instead of a hardware code");
        Check(fields["lensMake"].Text=="Samsung"&&fields["lens"].Text.Contains("S24 Ultra")&&fields["serial"].Text.StartsWith("OS"),"Applying a device fills lens manufacturer, model and a sample serial");
        string software=fields["software"].Text;Call(w,"GenerateSoftware");Check(fields["software"].Text!=software&&fields["software"].Text.StartsWith("S928BXX"),"Software Generate creates a new model-dependent build");
        var phoneMeta=(Metadata)typeof(MainWindow).GetMethod("Gather",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(w,null);Check(phoneMeta.Get("IFD0",0x0110)=="S24 Ultra"&&phoneMeta.Get("Exif",0xa433)=="Samsung"&&phoneMeta.Get("Exif",0xa431).StartsWith("OS"),"Generated device fields reach exported EXIF tags");

        canvas.Tool="Rectangle";canvas.FillShapes=true;canvas.Ink=Color.Red;int x=canvas.Width/2,y=canvas.Height/2;
        Call(canvas,"OnMouseDown",new MouseEventArgs(MouseButtons.Left,1,x-30,y-20,0));Call(canvas,"OnMouseMove",new MouseEventArgs(MouseButtons.Left,0,x+30,y+20,0));Call(canvas,"OnMouseUp",new MouseEventArgs(MouseButtons.Left,1,x+30,y+20,0));
        Check(canvas.Layers.Count==1&&canvas.Layers[0].Kind=="Rectangle"&&canvas.Layers[0].Bounds.Width>1,"Mouse gestures create actual editable rectangle");using(var b=canvas.Render(1600,1050))Check(b.GetPixel(800,525).R>240&&b.GetPixel(800,525).G<20,"Canvas export includes painted rectangle");canvas.Undo();Check(canvas.Layers.Count==0,"Undo removes drawing");canvas.Redo();Check(canvas.Layers.Count==1,"Redo restores drawing");
        fields["make"].Text="CustomBrand";fields["model"].Text="My custom phone";fields["lat"].Text="0";fields["lon"].Text="0";fields["title"].Text="تجربة";var m=(Metadata)typeof(MainWindow).GetMethod("Gather",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(w,null);
        Check(m.Get("IFD0",0x0110)=="My custom phone"&&m.Get("IFD0",0x010f)=="CustomBrand","Inspector applies custom camera name");Check(m.Coordinate(true)==0&&m.Coordinate(false)==0,"Inspector supports zero latitude / longitude");
        var dto=ProjectData.Create(canvas,m,"Custom.jpg");var json=new JavaScriptSerializer{MaxJsonLength=int.MaxValue}.Serialize(dto);var restored=new JavaScriptSerializer{MaxJsonLength=int.MaxValue}.Deserialize<ProjectData>(json);using(var c=new EditorCanvas()){restored.Apply(c);Check(c.Image.Width==1600&&c.Layers.Count==1&&c.Layers[0].Fill,"Editable project preserves pixels and layers");Check(restored.Metadata.Text["title"]=="تجربة"&&restored.Metadata.Get("IFD0",0x0110)=="My custom phone","Editable project preserves metadata and Unicode");}
        using(var raw=new RawMetadataForm(m)){raw.Show();Application.DoEvents();Check(raw.Controls.OfType<DataGridView>().First().Rows.Count>5,"Raw EXIF inspector renders actual tags");raw.Close();}
        using(var devices=new DeviceForm("Apple")){devices.Show();Application.DoEvents();var list=Get<ListBox>(devices,"list");Check(list.Items.Count==54,"Device picker shows all 54 listed iPhones");devices.Close();}
        using(var export=new ExportForm("Photo.jpg",1600,1050,"2026:10:10 12:00:00",true)){export.Show();Application.DoEvents();Check(export.Controls.OfType<NumericUpDown>().Count()==3,"Export settings render dimensions and quality");export.Close();}
        var last=Get<Metadata>(w,"metadata");last.Set("GPS",0x001d,2,"2026:10:10");var gathered=(Metadata)typeof(MainWindow).GetMethod("Gather",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(w,null);Check(gathered.Get("GPS",0x001d)=="2026:10:10","Advanced GPS tags survive ordinary inspector edits");
        if(args.Length>1){
            string fixtures=args[1];Call(w,"OpenPath",Path.Combine(fixtures,"identity.jpg"));Application.DoEvents();
            Check(fields["make"].Text=="Apple"&&fields["model"].Text=="iPhone X","Import immediately fills actual JPEG manufacturer and model");
            Check(fields["taken"].Text=="2024:04:01 12:34:56"&&fields["iso"].Text=="200"&&fields["shutter"].Text=="1/250","Import immediately fills actual dates and exposure values");
            Check(fields["lat"].Text=="-33.8688197"&&fields["lon"].Text=="151.2092955"&&fields["City"].Text=="Sydney","Import immediately fills actual embedded GPS and place text");
            Check(fields["title"].Text=="Arabic title: تجربة"&&Get<Panel>(w,"metaPage").Visible,"Import fills Unicode XMP and reveals the metadata inspector");
            Check(presetBrand.SelectedItem.Equals("Apple")&&((Device)presetList.SelectedItem).Name=="iPhone X","Imported device is highlighted in the sidebar without changing its metadata");
            Call(w,"OpenPath",Path.Combine(fixtures,"big-endian.jpg"));Application.DoEvents();Check(fields["model"].Text=="iPhone X"&&canvas.Image.Width==1050&&canvas.Image.Height==1600,"Big-endian JPEG imports camera metadata and corrects orientation");
            Check(fields["taken"].Text==""&&fields["lat"].Text==""&&fields["City"].Text=="","Opening another photo clears values absent from its own metadata");
            Call(w,"OpenPath",Path.Combine(fixtures,"identity.png"));Application.DoEvents();Check(fields["model"].Text=="iPhone X"&&fields["title"].Text=="Arabic title: تجربة","PNG import fills existing EXIF and Unicode XMP");
            var legacy=new Metadata();legacy.Set("IFD0",0x013b,2,"Camera artist");legacy.Set("IFD0",0x8298,2,"Camera copyright");legacy.Set("IFD0",0x010e,2,"Camera description");byte[] raw=File.ReadAllBytes(Path.Combine(fixtures,"stripped.jpg"));
            string legacyPath=Path.Combine(fixtures,"legacy-description.jpg");File.WriteAllBytes(legacyPath,Metadata.EmbedJpeg(raw,legacy));Call(w,"OpenPath",legacyPath);
            Check(fields["creator"].Text=="Camera artist"&&fields["rights"].Text=="Camera copyright"&&fields["description"].Text=="Camera description","Legacy EXIF artist, copyright and description also populate their fields");
            Call(w,"OpenPath",Path.Combine(fixtures,"stripped.jpg"));Check(fields["make"].Text==""&&fields["model"].Text==""&&fields["taken"].Text==""&&fields["creator"].Text=="","Images without metadata leave fields blank instead of retaining prior values");
            using(var pixels=System.Drawing.Image.FromStream(new MemoryStream(raw))){
                var formats=new[]{System.Drawing.Imaging.ImageFormat.Bmp,System.Drawing.Imaging.ImageFormat.Gif,System.Drawing.Imaging.ImageFormat.Tiff};
                foreach(var format in formats){string path=Path.Combine(fixtures,"raster-"+format.ToString()+".img");pixels.Save(path,format);Call(w,"OpenPath",path);Check(canvas.Image.Width==1600&&canvas.Image.Height==1050&&fields["model"].Text=="",format+" imports without fabricated device metadata");}
            }
        }
        w.Size=new Size(1536,940);Call(w,"LoadSample");canvas.LiftBackground();
        var imageLayer=canvas.ActiveLayer;canvas.SetMask(Pixels.ShapeMask(1600,1050,"Rounded rectangle"));
        canvas.Remember();imageLayer.ShadowOpacity=.5f;imageLayer.ShadowDistance=18;imageLayer.Resize(1240,815);imageLayer.Move(180,115);canvas.Commit();
        Call(w,"ShowPage","Layer");Application.DoEvents();
        Check(Get<Panel>(w,"layerPage").Visible&&Get<ComboBox>(w,"blendMode").Items.Count==7,"Layer inspector exposes seven working blend modes");
        var sliders=Get<Dictionary<string,TrackBar>>(w,"colorSliders");Check(sliders.Count==20,"Colour inspector exposes twenty tone, colour and detail controls");
        Call(w,"ShowPage","Color");sliders["Hue"].Value=35;Application.DoEvents();Check(canvas.ActiveLayer.Adjustments.Hue==35&&canvas.BackgroundAdjustments.Hue==0,"Colour controls edit the selected layer independently");canvas.Undo();Check(sliders["Hue"].Value==0,"Undo synchronizes colour controls with the restored layer state");
        Call(w,"ShowPage","Layer");Application.DoEvents();System.Threading.Thread.Sleep(100);using(var b=new Bitmap(w.Width,w.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(w.Location,Point.Empty,w.Size);b.Save(args[0],System.Drawing.Imaging.ImageFormat.Png);}typeof(MainWindow).GetField("dirty",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(w,false);w.Close();
    }Console.WriteLine("Completed "+count+" GUI checks.");}
}
}
