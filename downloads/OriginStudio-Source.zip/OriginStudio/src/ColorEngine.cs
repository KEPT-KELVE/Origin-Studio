using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Globalization;

namespace OriginStudio {
// All settings are non-destructive and are serialized with the project.
public sealed class ColorSettings {
    public float Exposure, Brightness, Highlights, Shadows, Whites, Blacks, Temperature, Tint, Hue, Vibrance, Sepia;
    public float Contrast=1, Saturation=1, Gamma=1, Red=1, Green=1, Blue=1;
    public float Blur, Sharpen, Pixelate;
    public bool Invert;
    public ColorSettings Clone(){return (ColorSettings)MemberwiseClone();}
    public string Key {get{return string.Join("|",new[]{Exposure,Brightness,Highlights,Shadows,Whites,Blacks,Temperature,Tint,Hue,Vibrance,Sepia,Contrast,Saturation,Gamma,Red,Green,Blue,Blur,Sharpen,Pixelate,Invert?1:0});}}
    public bool Neutral {get{return Exposure==0&&Brightness==0&&Highlights==0&&Shadows==0&&Whites==0&&Blacks==0&&Temperature==0&&Tint==0&&Hue==0&&Vibrance==0&&Sepia==0&&Contrast==1&&Saturation==1&&Gamma==1&&Red==1&&Green==1&&Blue==1&&Blur==0&&Sharpen==0&&Pixelate==0&&!Invert;}}
}
public static class Pixels {
    public static Bitmap Copy(Image source,int maxEdge=0){
        float ratio=maxEdge>0?Math.Min(1,maxEdge/(float)Math.Max(source.Width,source.Height)):1;
        var b=new Bitmap(Math.Max(1,(int)(source.Width*ratio)),Math.Max(1,(int)(source.Height*ratio)),PixelFormat.Format32bppArgb);
        using(var g=Graphics.FromImage(b)){g.CompositingMode=CompositingMode.SourceCopy;g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.DrawImage(source,new Rectangle(0,0,b.Width,b.Height));}return b;
    }
    public static byte[] Read(Bitmap b){
        var d=b.LockBits(new Rectangle(0,0,b.Width,b.Height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);var a=new byte[b.Width*b.Height*4];
        try{for(int y=0;y<b.Height;y++)Marshal.Copy(IntPtr.Add(d.Scan0,y*d.Stride),a,y*b.Width*4,b.Width*4);}finally{b.UnlockBits(d);}return a;
    }
    public static void Write(Bitmap b,byte[] a){
        var d=b.LockBits(new Rectangle(0,0,b.Width,b.Height),ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
        try{for(int y=0;y<b.Height;y++)Marshal.Copy(a,y*b.Width*4,IntPtr.Add(d.Scan0,y*d.Stride),b.Width*4);}finally{b.UnlockBits(d);}
    }
    static float Clamp(float n){return Math.Max(0,Math.Min(1,n));}
    static byte Byte(float n){return(byte)Math.Round(Clamp(n)*255);}
    public static void Adjust(Bitmap b,ColorSettings s){
        if(s==null||s.Neutral)return;var a=Read(b);float exposure=(float)Math.Pow(2,s.Exposure),gamma=1/Math.Max(.1f,s.Gamma);
        float angle=s.Hue*(float)Math.PI/180,cos=(float)Math.Cos(angle),sin=(float)Math.Sin(angle);
        for(int i=0;i<a.Length;i+=4){
            float r=a[i+2]/255f,g=a[i+1]/255f,bl=a[i]/255f;
            float lum=.2126f*r+.7152f*g+.0722f*bl;
            float tone=s.Shadows*(1-lum)*(1-lum)*.45f+s.Highlights*lum*lum*.45f+s.Blacks*(float)Math.Pow(1-lum,4)*.3f+s.Whites*(float)Math.Pow(lum,4)*.3f;
            r=((r*exposure+tone-.5f)*s.Contrast+.5f+s.Brightness+s.Temperature*.12f+s.Tint*.05f)*s.Red;
            g=((g*exposure+tone-.5f)*s.Contrast+.5f+s.Brightness-s.Tint*.10f)*s.Green;
            bl=((bl*exposure+tone-.5f)*s.Contrast+.5f+s.Brightness-s.Temperature*.12f+s.Tint*.05f)*s.Blue;
            if(s.Hue!=0){float y=.299f*r+.587f*g+.114f*bl,u=-.14713f*r-.28886f*g+.436f*bl,v=.615f*r-.51499f*g-.10001f*bl;float uu=u*cos-v*sin,vv=u*sin+v*cos;r=y+1.13983f*vv;g=y-.39465f*uu-.58060f*vv;bl=y+2.03211f*uu;}
            lum=.2126f*r+.7152f*g+.0722f*bl;float range=Math.Max(r,Math.Max(g,bl))-Math.Min(r,Math.Min(g,bl));float sat=s.Saturation*(1+s.Vibrance*(1-Clamp(range)));
            r=lum+(r-lum)*sat;g=lum+(g-lum)*sat;bl=lum+(bl-lum)*sat;
            if(s.Sepia>0){float rr=r*.393f+g*.769f+bl*.189f,gg=r*.349f+g*.686f+bl*.168f,bb=r*.272f+g*.534f+bl*.131f;r=r*(1-s.Sepia)+rr*s.Sepia;g=g*(1-s.Sepia)+gg*s.Sepia;bl=bl*(1-s.Sepia)+bb*s.Sepia;}
            r=(float)Math.Pow(Clamp(r),gamma);g=(float)Math.Pow(Clamp(g),gamma);bl=(float)Math.Pow(Clamp(bl),gamma);
            if(s.Invert){r=1-r;g=1-g;bl=1-bl;}a[i+2]=Byte(r);a[i+1]=Byte(g);a[i]=Byte(bl);
        }Write(b,a);
    }
    // Masks store coverage in RGB: white reveals and black hides, regardless of alpha.
    public static void Mask(Bitmap b,Bitmap mask){
        if(mask==null)return;using(var scaled=new Bitmap(b.Width,b.Height,PixelFormat.Format32bppArgb)){
            using(var g=Graphics.FromImage(scaled)){g.InterpolationMode=InterpolationMode.HighQualityBilinear;g.DrawImage(mask,new Rectangle(0,0,b.Width,b.Height));}
            var a=Read(b);var m=Read(scaled);for(int i=0;i<a.Length;i+=4)a[i+3]=(byte)(a[i+3]*m[i]/255);Write(b,a);
        }
    }
    public static Bitmap FromMask(Image image,string mode,int maxEdge=2048){
        var b=Copy(image,maxEdge);var a=Read(b);for(int i=0;i<a.Length;i+=4){double luminance=.2126*a[i+2]+.7152*a[i+1]+.0722*a[i];if(mode=="Dark silhouette")luminance=255-luminance;byte value=mode=="Alpha"?a[i+3]:(byte)Math.Max(0,Math.Min(255,Math.Round(luminance*a[i+3]/255)));a[i]=a[i+1]=a[i+2]=value;a[i+3]=255;}Write(b,a);return b;
    }
    public static Bitmap SolidMask(int width,int height,bool reveal){var b=new Bitmap(width,height,PixelFormat.Format32bppArgb);using(var g=Graphics.FromImage(b))g.Clear(reveal?Color.White:Color.Black);return b;}
    public static Bitmap ShapeMask(int width,int height,string shape){
        var b=SolidMask(width,height,false);using(var g=Graphics.FromImage(b))using(var path=new GraphicsPath()){
            g.SmoothingMode=SmoothingMode.AntiAlias;float inset=Math.Max(1,Math.Min(width,height)*.025f);var r=new RectangleF(inset,inset,width-inset*2,height-inset*2);
            if(shape=="Ellipse")path.AddEllipse(r);
            else if(shape=="Diamond")path.AddPolygon(new[]{new PointF(width/2f,inset),new PointF(width-inset,height/2f),new PointF(width/2f,height-inset),new PointF(inset,height/2f)});
            else if(shape=="Star"){var p=new PointF[10];for(int i=0;i<10;i++){double angle=-Math.PI/2+i*Math.PI/5;float radius=i%2==0?.48f:.21f;p[i]=new PointF(width/2f+(float)Math.Cos(angle)*width*radius,height/2f+(float)Math.Sin(angle)*height*radius);}path.AddPolygon(p);}
            else if(shape=="Rounded rectangle"){float d=Math.Min(width,height)*.24f;path.AddArc(r.X,r.Y,d,d,180,90);path.AddArc(r.Right-d,r.Y,d,d,270,90);path.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);path.AddArc(r.X,r.Bottom-d,d,d,90,90);path.CloseFigure();}
            else path.AddRectangle(r);g.FillPath(Brushes.White,path);
        }return b;
    }
    public static void InvertMask(Bitmap b){var a=Read(b);for(int i=0;i<a.Length;i+=4)a[i]=a[i+1]=a[i+2]=(byte)(255-a[i]);Write(b,a);}
    public static Bitmap Feather(Bitmap source,int radius){
        var b=Copy(source);if(radius<=0)return b;var a=Read(b);var tmp=new byte[a.Length];var dst=new byte[a.Length];int w=b.Width,h=b.Height;
        // Two separable box passes, with edge extension and bounded running sums.
        for(int pass=0;pass<2;pass++){
            for(int y=0;y<h;y++){int sum=0;for(int k=-radius;k<=radius;k++)sum+=a[(y*w+Math.Max(0,Math.Min(w-1,k)))*4];for(int x=0;x<w;x++){int i=(y*w+x)*4;tmp[i]=tmp[i+1]=tmp[i+2]=(byte)(sum/(radius*2+1));tmp[i+3]=255;sum-=a[(y*w+Math.Max(0,x-radius))*4];sum+=a[(y*w+Math.Min(w-1,x+radius+1))*4];}}
            for(int x=0;x<w;x++){int sum=0;for(int k=-radius;k<=radius;k++)sum+=tmp[(Math.Max(0,Math.Min(h-1,k))*w+x)*4];for(int y=0;y<h;y++){int i=(y*w+x)*4;dst[i]=dst[i+1]=dst[i+2]=(byte)(sum/(radius*2+1));dst[i+3]=255;sum-=tmp[(Math.Max(0,y-radius)*w+x)*4];sum+=tmp[(Math.Min(h-1,y+radius+1)*w+x)*4];}}var swap=a;a=dst;dst=swap;
        }Write(b,a);return b;
    }
    public static void Blend(Bitmap destination,Bitmap source,string mode,Bitmap clipping=null){
        var d=Read(destination);var s=Read(source);var clip=clipping==null?null:Read(clipping);
        for(int i=0;i<d.Length;i+=4){float sa=s[i+3]/255f*(clip==null?1:clip[i+3]/255f);if(sa<=0)continue;float da=d[i+3]/255f,alpha=sa+da*(1-sa);
            for(int c=0;c<3;c++){float a=s[i+c]/255f,b=d[i+c]/255f,m=a;
                if(mode=="Multiply")m=a*b;else if(mode=="Screen")m=1-(1-a)*(1-b);else if(mode=="Overlay")m=b<.5f?2*a*b:1-2*(1-a)*(1-b);else if(mode=="Darken")m=Math.Min(a,b);else if(mode=="Lighten")m=Math.Max(a,b);else if(mode=="Difference")m=Math.Abs(a-b);
                d[i+c]=Byte((sa*(1-da)*a+sa*da*m+(1-sa)*da*b)/Math.Max(.0001f,alpha));
            }d[i+3]=Byte(alpha);
        }Write(destination,d);
    }
}
}
