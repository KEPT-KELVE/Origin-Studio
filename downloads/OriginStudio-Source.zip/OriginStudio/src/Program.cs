using System;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Origin Studio")]
[assembly: AssemblyDescription("Native photo editor and EXIF / GPS metadata studio")]
[assembly: AssemblyCompany("Adam Ali")]
[assembly: AssemblyProduct("Origin Studio")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
namespace OriginStudio {
static class Program {
    // Keep the entry point independent of WinForms and editor types. A loader/JIT
    // failure in those types must happen inside the protected call, after logging.
    [STAThread] static int Main(string[] args){
        StartupLog.Begin();
        AppDomain.CurrentDomain.UnhandledException+=(s,e)=>StartupLog.Report(e.ExceptionObject as Exception);
        try {return StartEditor(args);}catch(Exception ex){StartupLog.Report(ex);return 1;}
    }
    [MethodImpl(MethodImplOptions.NoInlining)]
    static int StartEditor(string[] args){return EditorStartup.Run(args);}
}
}
