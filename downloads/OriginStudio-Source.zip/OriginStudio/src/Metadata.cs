using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Collections.Generic;
using System.Xml;

namespace OriginStudio {
public sealed class ExifTag {
    public string Group; public ushort Id, Type; public uint Count; public byte[] Data;
    public ExifTag Clone() { return new ExifTag { Group=Group, Id=Id, Type=Type, Count=Count, Data=(byte[])Data.Clone() }; }
    public string Key { get { return Group+":"+Id.ToString("X4"); } }
}
public sealed class Metadata {
    public List<ExifTag> Tags=new List<ExifTag>();
    public Dictionary<string,string> Text=new Dictionary<string,string>();
    public string OriginalXmp="";
    static readonly int[] Sizes={0,1,1,2,4,8,1,1,2,4,8,4,8};
    static uint U32(byte[] b,int p,bool le) { if(p<0||p+4>b.Length)throw new InvalidDataException("Invalid metadata offset."); return le?BitConverter.ToUInt32(b,p):(uint)(b[p]<<24|b[p+1]<<16|b[p+2]<<8|b[p+3]); }
    static ushort U16(byte[] b,int p,bool le) { if(p<0||p+2>b.Length)throw new InvalidDataException("Invalid metadata offset.");return le?BitConverter.ToUInt16(b,p):(ushort)(b[p]<<8|b[p+1]); }
    public static Metadata Read(byte[] image) {
        var m=new Metadata();
        if(image.Length<8)return m;
        if(image[0]==255&&image[1]==216) {
            int p=2;
            while(p+4<=image.Length) {
                if(image[p++]!=255)break; while(p<image.Length&&image[p]==255)p++;
                if(p>=image.Length)break; int marker=image[p++]; if(marker==0xda||marker==0xd9)break;
                if(marker==0x01||(marker>=0xd0&&marker<=0xd7))continue;
                int len=(image[p]<<8)|image[p+1]; if(len<2||p+len>image.Length)break;
                if(marker==0xe1&&len>8&&Encoding.ASCII.GetString(image,p+2,6)=="Exif\0\0") m.ReadTiff(image.Skip(p+8).Take(len-8).ToArray());
                if(marker==0xe1&&len>31&&Encoding.ASCII.GetString(image,p+2,29)=="http://ns.adobe.com/xap/1.0/\0") m.ReadXmp(Encoding.UTF8.GetString(image,p+31,len-31));
                p+=len;
            }
        } else if(image[0]==137&&image[1]==80) {
            int p=8;
            while(p+12<=image.Length) {
                uint n=U32(image,p,false); if(n>int.MaxValue||p+12L+n>image.Length)break;
                string kind=Encoding.ASCII.GetString(image,p+4,4); int length=(int)n;
                if(kind=="eXIf")m.ReadTiff(image.Skip(p+8).Take(length).ToArray());
                if(kind=="iTXt") {
                    var data=image.Skip(p+8).Take(length).ToArray();int end=Array.IndexOf(data,(byte)0);
                    if(end>0&&Encoding.ASCII.GetString(data,0,end)=="XML:com.adobe.xmp"&&end+5<=data.Length&&data[end+1]==0) {
                        int q=end+3;while(q<data.Length&&data[q]!=0)q++;q++;while(q<data.Length&&data[q]!=0)q++;q++;
                        if(q<=data.Length)m.ReadXmp(Encoding.UTF8.GetString(data,q,data.Length-q));
                    }
                }
                p+=12+length;
            }
        } else if((image[0]==73&&image[1]==73)||(image[0]==77&&image[1]==77))m.ReadTiff(image);
        return m;
    }
    void ReadTiff(byte[] b) {
        try {
            if(b.Length<8)return;bool le=b[0]==73&&b[1]==73;
            if(!le&&!(b[0]==77&&b[1]==77))return;if(U16(b,2,le)!=42)return;
            ReadIfd(b,(int)U32(b,4,le),"IFD0",le,new HashSet<int>(),0);
        } catch(InvalidDataException) { } catch(ArgumentException) { } catch(OverflowException) { }
    }
    void ReadIfd(byte[] b,int p,string group,bool le,HashSet<int> seen,int depth) {
        if(p<8||p+2>b.Length||depth>5||!seen.Add(p))return;
        int count=U16(b,p,le);if(count>4096||p+2L+12L*count+4>b.Length)return;
        for(int i=0;i<count;i++) {
            int q=p+2+i*12;ushort id=U16(b,q,le),type=U16(b,q+2,le);uint n=U32(b,q+4,le);
            if(type<1||type>12||n>1000000)continue;long len=(long)n*Sizes[type];
            int d=len<=4?q+8:(int)U32(b,q+8,le);if(d<0||d+len>b.Length)continue;
            if(id==0x8769||id==0x8825||id==0xa005) { ReadIfd(b,(int)U32(b,q+8,le),id==0x8769?"Exif":id==0x8825?"GPS":"Interop",le,seen,depth+1); continue; }
            byte[] value=b.Skip(d).Take((int)len).ToArray();
            if(!le&&type!=1&&type!=2&&type!=6&&type!=7) { int chunk=(type==5||type==10)?4:Sizes[type];for(int z=0;z+chunk<=value.Length;z+=chunk)Array.Reverse((Array)value,z,chunk); }
            Tags.RemoveAll(t=>t.Group==group&&t.Id==id);Tags.Add(new ExifTag{Group=group,Id=id,Type=type,Count=n,Data=value});
        }
    }
    void ReadXmp(string s) {
        OriginalXmp=s;
        try {
            var xml=new XmlDocument();xml.XmlResolver=null;xml.LoadXml(s);
            string[] fields={"title","description","creator","rights","City","State","Country","Location","Keywords","label"};
            foreach(string field in fields) { var node=xml.SelectSingleNode("//*[local-name()='"+field+"']");if(node!=null)Text[field]=node.InnerText; }
            foreach(XmlElement e in xml.GetElementsByTagName("rdf:Description"))foreach(XmlAttribute a in e.Attributes)if(fields.Contains(a.LocalName))Text[a.LocalName]=a.Value;
        }catch(XmlException) { }
    }
    public Metadata Clone() { return new Metadata { Tags=Tags.Select(t=>t.Clone()).ToList(),Text=new Dictionary<string,string>(Text),OriginalXmp=OriginalXmp }; }
    public string Get(string group,ushort id,string fallback="") { var t=Tags.FirstOrDefault(x=>x.Group==group&&x.Id==id);return t==null?fallback:Display(t); }
    public ExifTag Find(string group,ushort id) { return Tags.FirstOrDefault(t=>t.Group==group&&t.Id==id); }
    public void Remove(string group,ushort id) { Tags.RemoveAll(t=>t.Group==group&&t.Id==id); }
    public void Set(string group,ushort id,ushort type,string value) {
        if(string.IsNullOrWhiteSpace(value)) {Remove(group,id);return;}
        var t=Parse(group,id,type,value);Remove(group,id);Tags.Add(t);
    }
    public static ExifTag Parse(string group,ushort id,ushort type,string value) {
        var data=new List<byte>();uint count=0;
        if(type==2) {data.AddRange(Encoding.ASCII.GetBytes(value));data.Add(0);count=(uint)data.Count;}
        else if(type==7) {string hex=value.Replace(" ","").Replace("-","").Replace("0x","");if(hex.Length%2!=0)throw new FormatException("Hex bytes need two digits per byte.");for(int i=0;i<hex.Length;i+=2)data.Add(byte.Parse(hex.Substring(i,2),NumberStyles.HexNumber));count=(uint)data.Count;}
        else {
            var tokens=value.Split(new[]{',',';',' '},StringSplitOptions.RemoveEmptyEntries); count=(uint)tokens.Length;
            foreach(var tok in tokens) {
                switch(type) {
                    case 1:data.Add(byte.Parse(tok,CultureInfo.InvariantCulture));break;
                    case 3:data.AddRange(BitConverter.GetBytes(ushort.Parse(tok,CultureInfo.InvariantCulture)));break;
                    case 4:data.AddRange(BitConverter.GetBytes(uint.Parse(tok,CultureInfo.InvariantCulture)));break;
                    case 5:case 10:
                        var f=tok.Split(new[]{'/'});double v=double.Parse(f[0],CultureInfo.InvariantCulture);double den=f.Length==2?double.Parse(f[1],CultureInfo.InvariantCulture):1000000;double num=f.Length==2?v:v*den;
                        if(den<=0||double.IsNaN(num)||double.IsInfinity(num))throw new FormatException("Rational denominator must be positive.");
                        if(type==5) {if(num<0||num>uint.MaxValue||den>uint.MaxValue)throw new FormatException("Unsigned rational is outside its range.");data.AddRange(BitConverter.GetBytes((uint)Math.Round(num)));data.AddRange(BitConverter.GetBytes((uint)Math.Round(den)));}
                        else {data.AddRange(BitConverter.GetBytes(checked((int)Math.Round(num))));data.AddRange(BitConverter.GetBytes(checked((int)Math.Round(den))));}break;
                    case 6:data.Add(unchecked((byte)sbyte.Parse(tok,CultureInfo.InvariantCulture)));break;
                    case 8:data.AddRange(BitConverter.GetBytes(short.Parse(tok,CultureInfo.InvariantCulture)));break;
                    case 9:data.AddRange(BitConverter.GetBytes(int.Parse(tok,CultureInfo.InvariantCulture)));break;
                    case 11:data.AddRange(BitConverter.GetBytes(float.Parse(tok,CultureInfo.InvariantCulture)));break;
                    case 12:data.AddRange(BitConverter.GetBytes(double.Parse(tok,CultureInfo.InvariantCulture)));break;
                    default:throw new FormatException("Choose an EXIF type from 1 to 12.");
                }
            }
        }
        return new ExifTag{Group=group,Id=id,Type=type,Count=count,Data=data.ToArray()};
    }
    public static string Display(ExifTag t) {
        if(t.Type==2)return Encoding.ASCII.GetString(t.Data).TrimEnd(new[]{'\0'});
        if(t.Type==7)return BitConverter.ToString(t.Data).Replace("-"," ");
        var vals=new List<string>();int size=Sizes[t.Type];
        for(int i=0;i<t.Data.Length;i+=size) {
            switch(t.Type) {
                case 1:vals.Add(t.Data[i].ToString());break;case 3:vals.Add(BitConverter.ToUInt16(t.Data,i).ToString());break;
                case 4:vals.Add(BitConverter.ToUInt32(t.Data,i).ToString());break;
                case 5:vals.Add(BitConverter.ToUInt32(t.Data,i)+"/"+BitConverter.ToUInt32(t.Data,i+4));break;
                case 6:vals.Add(((sbyte)t.Data[i]).ToString());break;case 8:vals.Add(BitConverter.ToInt16(t.Data,i).ToString());break;
                case 9:vals.Add(BitConverter.ToInt32(t.Data,i).ToString());break;
                case 10:vals.Add(BitConverter.ToInt32(t.Data,i)+"/"+BitConverter.ToInt32(t.Data,i+4));break;
                case 11:vals.Add(BitConverter.ToSingle(t.Data,i).ToString("R",CultureInfo.InvariantCulture));break;
                case 12:vals.Add(BitConverter.ToDouble(t.Data,i).ToString("R",CultureInfo.InvariantCulture));break;
            }
        }
        return string.Join(", ",vals);
    }
    public double Number(string group,ushort id,double fallback=0) {
        var t=Find(group,id);if(t==null||t.Data.Length==0)return fallback;
        if(t.Type==5&&t.Data.Length>=8) {uint d=BitConverter.ToUInt32(t.Data,4);return d==0?fallback:(double)BitConverter.ToUInt32(t.Data,0)/d;}
        if(t.Type==10&&t.Data.Length>=8) {int d=BitConverter.ToInt32(t.Data,4);return d==0?fallback:(double)BitConverter.ToInt32(t.Data,0)/d;}
        double x;return double.TryParse(Display(t),NumberStyles.Float,CultureInfo.InvariantCulture,out x)?x:fallback;
    }
    public double? Coordinate(bool lat) {
        var t=Find("GPS",(ushort)(lat?2:4));if(t==null||t.Type!=5||t.Data.Length<24)return null;
        double result=0;for(int i=0;i<3;i++) {uint d=BitConverter.ToUInt32(t.Data,i*8+4);if(d==0)return null;result+=(double)BitConverter.ToUInt32(t.Data,i*8)/d/Math.Pow(60,i);}
        string sign=Get("GPS",(ushort)(lat?1:3));if(sign=="S"||sign=="W")result=-result;return result;
    }
    public void SetGps(double lat,double lon,double altitude=0) {
        if(double.IsNaN(lat)||double.IsNaN(lon)||Math.Abs(lat)>90||Math.Abs(lon)>180)throw new FormatException("Latitude must be -90 to 90; longitude -180 to 180.");
        Set("GPS",0,1,"2, 3, 0, 0");Set("GPS",1,2,lat<0?"S":"N");Set("GPS",3,2,lon<0?"W":"E");
        Set("GPS",2,5,Dms(lat));Set("GPS",4,5,Dms(lon));Set("GPS",5,1,altitude<0?"1":"0");Set("GPS",6,5,Math.Abs(altitude).ToString(CultureInfo.InvariantCulture));Set("GPS",18,2,"WGS-84");
    }
    static string Dms(double v) { v=Math.Abs(v);int deg=(int)v;int min=(int)((v-deg)*60);double sec=(v-deg-min/60.0)*3600;return deg+"/1, "+min+"/1, "+Math.Round(sec*1000000).ToString(CultureInfo.InvariantCulture)+"/1000000"; }
    public byte[] TiffBytes() {
        var clean=Tags.Where(t=>t.Id!=0x8769&&t.Id!=0x8825&&t.Id!=0xa005&&t.Id!=0x927c&&t.Id!=0x0201&&t.Id!=0x0202&&t.Id!=0x0111&&t.Id!=0x0117&&t.Id!=0x0144&&t.Id!=0x0145).Select(t=>t.Clone()).ToList();
        var groups=new List<string>{"IFD0"};if(clean.Any(t=>t.Group=="Exif"||t.Group=="Interop"))groups.Add("Exif");if(clean.Any(t=>t.Group=="GPS"))groups.Add("GPS");if(clean.Any(t=>t.Group=="Interop"))groups.Add("Interop");
        if(groups.Contains("Exif")){
            clean.Add(Parse("IFD0",0x8769,4,"0"));
            if(!clean.Any(t=>t.Group=="Exif"&&t.Id==0x9000))clean.Add(Parse("Exif",0x9000,7,"30 32 33 32"));
            if(!clean.Any(t=>t.Group=="Exif"&&t.Id==0xa000))clean.Add(Parse("Exif",0xa000,7,"30 31 30 30"));
        }
        if(groups.Contains("GPS"))clean.Add(Parse("IFD0",0x8825,4,"0"));if(groups.Contains("Interop"))clean.Add(Parse("Exif",0xa005,4,"0"));
        var dirs=groups.ToDictionary(g=>g,g=>clean.Where(t=>t.Group==g).OrderBy(t=>t.Id).ToList());
        var offsets=new Dictionary<string,int>();int pos=8;foreach(string g in groups){offsets[g]=pos;pos+=2+dirs[g].Count*12+4;}
        foreach(var t in clean) {string target=t.Id==0x8769?"Exif":t.Id==0x8825?"GPS":t.Id==0xa005?"Interop":null;if(target!=null)t.Data=BitConverter.GetBytes(offsets[target]);}
        using(var ms=new MemoryStream())using(var w=new BinaryWriter(ms)) {
            w.Write(new byte[]{73,73,42,0});w.Write((uint)8);ms.SetLength(pos);int dataPos=pos;
            foreach(string g in groups) {
                ms.Position=offsets[g];w.Write((ushort)dirs[g].Count);
                foreach(var t in dirs[g]) {
                    w.Write(t.Id);w.Write(t.Type);w.Write(t.Count);
                    if(t.Data.Length<=4) {w.Write(t.Data);w.Write(new byte[4-t.Data.Length]);}
                    else {w.Write((uint)dataPos);long restore=ms.Position;ms.Position=dataPos;w.Write(t.Data);if(t.Data.Length%2==1)w.Write((byte)0);dataPos=(int)ms.Position;ms.Position=restore;}
                }
                w.Write((uint)0);
            }
            return ms.ToArray();
        }
    }
    static string Esc(string x) { return System.Security.SecurityElement.Escape(x??""); }
    public byte[] XmpBytes() {
        var s=new StringBuilder("<x:xmpmeta xmlns:x=\"adobe:ns:meta/\"><rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"><rdf:Description rdf:about=\"\" xmlns:tiff=\"http://ns.adobe.com/tiff/1.0/\" xmlns:exif=\"http://ns.adobe.com/exif/1.0/\" xmlns:aux=\"http://ns.adobe.com/exif/1.0/aux/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:photoshop=\"http://ns.adobe.com/photoshop/1.0/\" xmlns:Iptc4xmpCore=\"http://iptc.org/std/Iptc4xmpCore/1.0/xmlns/\">");
        Action<string,string> scalar=(key,val)=> {if(!string.IsNullOrEmpty(val))s.Append("<"+key+">"+Esc(val)+"</"+key+">");};
        scalar("tiff:Make",Get("IFD0",0x010f));scalar("tiff:Model",Get("IFD0",0x0110));scalar("tiff:Software",Get("IFD0",0x0131));scalar("aux:Lens",Get("Exif",0xa434));
        foreach(string field in new[]{"title","description","rights"})if(Text.ContainsKey(field)&&Text[field]!="")s.Append("<dc:"+field+"><rdf:Alt><rdf:li xml:lang=\"x-default\">"+Esc(Text[field])+"</rdf:li></rdf:Alt></dc:"+field+">");
        if(Text.ContainsKey("creator")&&Text["creator"]!="")s.Append("<dc:creator><rdf:Seq><rdf:li>"+Esc(Text["creator"])+"</rdf:li></rdf:Seq></dc:creator>");
        foreach(string field in new[]{"City","State","Country"})if(Text.ContainsKey(field))scalar("photoshop:"+field,Text[field]);
        if(Text.ContainsKey("Location"))scalar("Iptc4xmpCore:Location",Text["Location"]);
        if(Text.ContainsKey("Keywords"))s.Append("<dc:subject><rdf:Bag>"+string.Join("",Text["Keywords"].Split(new[]{','}).Where(v=>v.Trim()!="").Select(v=>"<rdf:li>"+Esc(v.Trim())+"</rdf:li>"))+"</rdf:Bag></dc:subject>");
        s.Append("</rdf:Description></rdf:RDF></x:xmpmeta>");return Encoding.UTF8.GetBytes(s.ToString());
    }
    static void Segment(Stream dst,byte marker,byte[] payload) { if(payload.Length>65533)throw new InvalidDataException("Metadata exceeds the JPEG 64 KB segment limit. Shorten large raw tags or export PNG.");dst.WriteByte(255);dst.WriteByte(marker);int n=payload.Length+2;dst.WriteByte((byte)(n>>8));dst.WriteByte((byte)n);dst.Write(payload,0,payload.Length); }
    public static byte[] EmbedJpeg(byte[] jpg,Metadata m,bool strip=false) {
        if(jpg.Length<2||jpg[0]!=255||jpg[1]!=216)throw new InvalidDataException("Not a JPEG file.");
        using(var dst=new MemoryStream()) {
            dst.WriteByte(255);dst.WriteByte(216);
            if(!strip) { Segment(dst,0xe1,Encoding.ASCII.GetBytes("Exif\0\0").Concat(m.TiffBytes()).ToArray());Segment(dst,0xe1,Encoding.ASCII.GetBytes("http://ns.adobe.com/xap/1.0/\0").Concat(m.XmpBytes()).ToArray()); }
            int p=2;while(p+4<=jpg.Length) {
                int start=p;if(jpg[p++]!=255)throw new InvalidDataException("JPEG marker stream is malformed.");while(p<jpg.Length&&jpg[p]==255)p++;if(p>=jpg.Length)break;
                byte marker=jpg[p++];if(marker==0xda||marker==0xd9) {dst.Write(jpg,start,jpg.Length-start);return dst.ToArray();}
                if(marker==0x01||(marker>=0xd0&&marker<=0xd7)) {dst.Write(jpg,start,p-start);continue;}
                int n=(jpg[p]<<8)|jpg[p+1];if(n<2||p+n>jpg.Length)throw new InvalidDataException("JPEG segment length is invalid.");
                bool icc=marker==0xe2&&n>=16&&Encoding.ASCII.GetString(jpg,p+2,12)=="ICC_PROFILE\0";
                bool metadata=(marker==0xe1||marker==0xe2||marker==0xed||marker==0xfe)&&(!icc||strip);
                if(!metadata)dst.Write(jpg,start,p+n-start);p+=n;
            }
            throw new InvalidDataException("JPEG scan was not found.");
        }
    }
    static uint Crc(byte[] data) { uint c=0xffffffff;foreach(byte v in data){c^=v;for(int j=0;j<8;j++)c=(c&1)!=0?0xedb88320^(c>>1):c>>1;}return c^0xffffffff; }
    static void Chunk(Stream dst,string kind,byte[] payload) { var k=Encoding.ASCII.GetBytes(kind);int n=payload.Length;dst.Write(new byte[]{(byte)(n>>24),(byte)(n>>16),(byte)(n>>8),(byte)n},0,4);dst.Write(k,0,4);dst.Write(payload,0,n);uint crc=Crc(k.Concat(payload).ToArray());dst.Write(new byte[]{(byte)(crc>>24),(byte)(crc>>16),(byte)(crc>>8),(byte)crc},0,4); }
    public static byte[] EmbedPng(byte[] png,Metadata m,bool strip=false) {
        if(png.Length<8||png[0]!=137||png[1]!=80)throw new InvalidDataException("Not a PNG file.");
        using(var dst=new MemoryStream()) {
            dst.Write(png,0,8);int p=8;bool wrote=false;
            while(p+12<=png.Length) {
                uint n=U32(png,p,false);if(n>int.MaxValue||p+12L+n>png.Length)throw new InvalidDataException("PNG chunk length is invalid.");string kind=Encoding.ASCII.GetString(png,p+4,4);
                if(!wrote&&(kind=="IDAT"||kind=="IEND")) { if(!strip) {Chunk(dst,"eXIf",m.TiffBytes());Chunk(dst,"iTXt",Encoding.ASCII.GetBytes("XML:com.adobe.xmp\0\0\0\0\0").Concat(m.XmpBytes()).ToArray());}wrote=true; }
                if(kind!="eXIf"&&kind!="tEXt"&&kind!="iTXt"&&kind!="zTXt")dst.Write(png,p,12+(int)n);p+=12+(int)n;
            }
            return dst.ToArray();
        }
    }
    public static readonly Dictionary<ushort,string> Names=new Dictionary<ushort,string> {
        {0x010e,"Description"},{0x010f,"Manufacturer"},{0x0110,"Camera model"},{0x0112,"Orientation"},{0x0131,"Software"},{0x0132,"Modified date"},{0x013b,"Artist"},{0x8298,"Copyright"},
        {0x829a,"Exposure time"},{0x829d,"Aperture"},{0x8827,"ISO"},{0x9003,"Date taken"},{0x9004,"Digitized date"},{0x9011,"Time zone"},{0x9201,"Shutter speed"},{0x9202,"Aperture value"},{0x9204,"Exposure bias"},{0x9209,"Flash"},{0x920a,"Focal length"},{0x9286,"User comment"},{0xa001,"Color space"},{0xa002,"Pixel width"},{0xa003,"Pixel height"},{0xa405,"35mm focal length"},{0xa430,"Camera owner"},{0xa431,"Body serial number"},{0xa433,"Lens manufacturer"},{0xa434,"Lens model"},{0xa435,"Lens serial number"},{0x927c,"Manufacturer MakerNote"}
    };
}
}
