using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Collections.Generic;

namespace OriginStudio {
public static class Theme {
    public static Color Back=Color.FromArgb(22,23,26),Panel=Color.FromArgb(30,31,35),Inset=Color.FromArgb(24,25,28),Line=Color.FromArgb(53,54,62),Muted=Color.FromArgb(155,158,173),Text=Color.FromArgb(231,232,239),Accent=Color.FromArgb(173,150,255),Green=Color.FromArgb(127,211,178);
    public static Font Font=new Font("Segoe UI",9f), Small=new Font("Segoe UI",8f), Bold=new Font("Segoe UI",9f,FontStyle.Bold);
    public static Button Button(string text,Action click,bool primary=false) {
        var b=new Button {Text=text,FlatStyle=FlatStyle.Flat,BackColor=primary?Accent:Color.FromArgb(43,44,51),ForeColor=primary?Color.FromArgb(24,20,35):Text,Font=Bold,Height=32,Cursor=Cursors.Hand,Margin=new Padding(4),TabStop=true,UseMnemonic=false};
        b.FlatAppearance.BorderSize=primary?0:1;b.FlatAppearance.BorderColor=Line;b.FlatAppearance.MouseOverBackColor=primary?Color.FromArgb(191,172,255):Color.FromArgb(59,60,68);b.Click+=(s,e)=>click();return b;
    }
    public static Label Label(string text,bool bold=false) { return new Label{Text=text,ForeColor=bold?Text:Muted,Font=bold?Bold:Font,AutoSize=true,UseMnemonic=false,Margin=new Padding(4,7,4,4)}; }
    public static TextBox Edit(string text="") { return new TextBox {Text=text,BorderStyle=BorderStyle.FixedSingle,BackColor=Inset,ForeColor=Text,Font=Font,Height=27}; }
    public static void Style(Form f) {f.BackColor=Back;f.ForeColor=Text;f.Font=Font;f.StartPosition=FormStartPosition.CenterParent;f.AutoScaleMode=AutoScaleMode.Dpi;}
}
public sealed class Histogram : Control {
    public Bitmap Source;public Histogram(){DoubleBuffered=true;Height=74;Dock=DockStyle.Fill;BackColor=Theme.Inset;}
    protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);e.Graphics.Clear(BackColor);if(Source==null)return;int[][] hist={new int[64],new int[64],new int[64]};using(var b=new Bitmap(Source,new Size(100,70))){for(int y=0;y<b.Height;y++)for(int x=0;x<b.Width;x++){var c=b.GetPixel(x,y);hist[0][c.R/4]++;hist[1][c.G/4]++;hist[2][c.B/4]++;}}int max=hist.Max(a=>a.Max());Color[] colors={Color.FromArgb(90,238,107,140),Color.FromArgb(90,116,212,179),Color.FromArgb(110,143,165,255)};for(int c=0;c<3;c++){var points=new List<PointF>{new PointF(0,Height)};for(int i=0;i<64;i++)points.Add(new PointF(i*Width/63f,Height-4-(Height-8)*hist[c][i]/(float)Math.Max(1,max)));points.Add(new PointF(Width,Height));using(var b=new SolidBrush(colors[c]))e.Graphics.FillPolygon(b,points.ToArray());}using(var pen=new Pen(Theme.Line))for(int i=1;i<4;i++)e.Graphics.DrawLine(pen,0,i*Height/4,Width,i*Height/4);}
}
}
