using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Collections.Generic;

namespace OriginStudio {
public sealed class Layer {
    public string Kind,Name,Text="",Blend="Normal",FontFamily="Segoe UI";
    public List<PointF> Points=new List<PointF>();
    public RectangleF Bounds;
    public Color Color=Color.White;
    public float Width=8,Opacity=1,Rotation,ShadowOpacity,ShadowDistance=12,OutlineWidth;
    public Color OutlineColor=Color.White;
    public bool Fill,Visible=true,Locked,ClipToBelow,FlipX,FlipY,MaskEnabled=true,Bold=true,Italic;
    public Bitmap Pixels,Mask;
    public ColorSettings Adjustments=new ColorSettings();
    Bitmap cached;string cacheKey;
    public Layer Clone(){return new Layer{Kind=Kind,Name=Name,Text=Text,Blend=Blend,FontFamily=FontFamily,Bold=Bold,Italic=Italic,ShadowOpacity=ShadowOpacity,ShadowDistance=ShadowDistance,OutlineWidth=OutlineWidth,OutlineColor=OutlineColor,Points=new List<PointF>(Points),Bounds=Bounds,Color=Color,Width=Width,Opacity=Opacity,Fill=Fill,Visible=Visible,Locked=Locked,ClipToBelow=ClipToBelow,Rotation=Rotation,FlipX=FlipX,FlipY=FlipY,MaskEnabled=MaskEnabled,Pixels=Pixels,Mask=Mask,Adjustments=Adjustments.Clone()};}
    public RectangleF ContentBounds {
        get{if(Points.Count>0&&(Kind=="Brush"||Kind=="Line")){float x=Points.Min(p=>p.X)-Width,y=Points.Min(p=>p.Y)-Width;return new RectangleF(x,y,Math.Max(1,Points.Max(p=>p.X)-x+Width),Math.Max(1,Points.Max(p=>p.Y)-y+Width));}var r=Bounds;if(Kind!="Image"&&Kind!="Text"&&!Fill)r.Inflate(Width,Width);return new RectangleF(r.X,r.Y,Math.Max(1,r.Width),Math.Max(1,r.Height));}
    }
    public void ClearCache(){if(cached!=null){cached.Dispose();cached=null;}cacheKey=null;}
    void Vector(Graphics g){
        using(var pen=new Pen(Color,Width))using(var brush=new SolidBrush(Color)){
            pen.StartCap=pen.EndCap=LineCap.Round;pen.LineJoin=LineJoin.Round;
            if(Kind=="Brush"){if(Points.Count==1)g.FillEllipse(brush,Points[0].X-Width/2,Points[0].Y-Width/2,Width,Width);else if(Points.Count>1)g.DrawLines(pen,Points.ToArray());}
            else if(Kind=="Rectangle"){if(Fill)g.FillRectangle(brush,Bounds);else g.DrawRectangle(pen,Bounds.X,Bounds.Y,Bounds.Width,Bounds.Height);}
            else if(Kind=="Ellipse"){if(Fill)g.FillEllipse(brush,Bounds);else g.DrawEllipse(pen,Bounds);}
            else if(Kind=="Line"&&Points.Count>1)g.DrawLine(pen,Points[0],Points[1]);
            else if(Kind=="Text")using(var font=new Font(FontFamily,Math.Max(8,Width*3),(Bold?FontStyle.Bold:FontStyle.Regular)|(Italic?FontStyle.Italic:FontStyle.Regular),GraphicsUnit.Pixel))g.DrawString(Text??"",font,brush,Bounds.Location);
        }
    }
    public Bitmap Surface(int maxEdge){
        var r=ContentBounds;string key=Adjustments.Key+"/"+maxEdge+"/"+(MaskEnabled?"on":"off");
        if(cached!=null&&cacheKey==key)return cached;ClearCache();
        if(Pixels!=null)cached=OriginStudio.Pixels.Copy(Pixels,maxEdge);
        else{float ratio=maxEdge>0?Math.Min(1,maxEdge/Math.Max(r.Width,r.Height)):1;int w=Math.Max(1,(int)Math.Ceiling(r.Width*ratio)),h=Math.Max(1,(int)Math.Ceiling(r.Height*ratio));if((long)w*h>120000000)throw new InvalidOperationException("Layer is too large to rasterize.");cached=new Bitmap(w,h,PixelFormat.Format32bppArgb);using(var g=Graphics.FromImage(cached)){g.SmoothingMode=SmoothingMode.AntiAlias;g.ScaleTransform(w/r.Width,h/r.Height);g.TranslateTransform(-r.X,-r.Y);Vector(g);}}
        OriginStudio.Pixels.Adjust(cached,Adjustments);RasterFilters.Apply(cached,Adjustments,cached.Width/(Pixels==null?r.Width:Pixels.Width));if(MaskEnabled)OriginStudio.Pixels.Mask(cached,Mask);cacheKey=key;return cached;
    }
    public void Draw(Graphics g){Draw(g,0);}
    public void Draw(Graphics g,int maxEdge){
        if(!Visible||Kind=="Adjustment")return;var r=ContentBounds;var bitmap=Surface(maxEdge);var state=g.Save();g.TranslateTransform(r.X+r.Width/2,r.Y+r.Height/2);g.RotateTransform(Rotation);g.ScaleTransform(FlipX?-1:1,FlipY?-1:1);
        if(ShadowOpacity>0)DrawTint(g,bitmap,r,ShadowDistance,ShadowDistance,Color.Black,ShadowOpacity*Opacity);
        if(OutlineWidth>0)for(int k=0;k<12;k++){double a=k*Math.PI/6;DrawTint(g,bitmap,r,(float)Math.Cos(a)*OutlineWidth,(float)Math.Sin(a)*OutlineWidth,OutlineColor,Opacity);}
        using(var attrs=new ImageAttributes()){var matrix=new ColorMatrix();matrix.Matrix33=Math.Max(0,Math.Min(1,Opacity));attrs.SetColorMatrix(matrix);DrawBitmap(g,bitmap,new RectangleF(-r.Width/2,-r.Height/2,r.Width,r.Height),attrs);}g.Restore(state);
    }
    public static void DrawBitmap(Graphics g,Bitmap bitmap,RectangleF bounds,ImageAttributes attrs){var state=g.Save();g.TranslateTransform(bounds.X,bounds.Y);g.ScaleTransform(bounds.Width/bitmap.Width,bounds.Height/bitmap.Height);g.DrawImage(bitmap,new Rectangle(0,0,bitmap.Width,bitmap.Height),0,0,bitmap.Width,bitmap.Height,GraphicsUnit.Pixel,attrs);g.Restore(state);}
    static void DrawTint(Graphics g,Bitmap b,RectangleF r,float dx,float dy,Color color,float opacity){using(var attrs=new ImageAttributes()){var m=new ColorMatrix();m.Matrix00=m.Matrix11=m.Matrix22=0;m.Matrix40=color.R/255f;m.Matrix41=color.G/255f;m.Matrix42=color.B/255f;m.Matrix33=opacity;attrs.SetColorMatrix(m);DrawBitmap(g,b,new RectangleF(-r.Width/2+dx,-r.Height/2+dy,r.Width,r.Height),attrs);}}
    public PointF LocalPoint(PointF p){var r=ContentBounds;float x=p.X-r.X-r.Width/2,y=p.Y-r.Y-r.Height/2,angle=-Rotation*(float)Math.PI/180;float xx=x*(float)Math.Cos(angle)-y*(float)Math.Sin(angle),yy=x*(float)Math.Sin(angle)+y*(float)Math.Cos(angle);return new PointF((FlipX?-xx:xx)/r.Width+.5f,(FlipY?-yy:yy)/r.Height+.5f);}
    public bool Hit(PointF p,float tolerance){if(!Visible)return false;var local=LocalPoint(p);var r=ContentBounds;return local.X>=-tolerance/r.Width&&local.X<=1+tolerance/r.Width&&local.Y>=-tolerance/r.Height&&local.Y<=1+tolerance/r.Height;}
    public void Move(float x,float y){Bounds=new RectangleF(Bounds.X+x,Bounds.Y+y,Bounds.Width,Bounds.Height);for(int i=0;i<Points.Count;i++)Points[i]=new PointF(Points[i].X+x,Points[i].Y+y);if(Pixels==null)ClearCache();}
    public void Resize(float width,float height){
        width=Math.Max(1,width);height=Math.Max(1,height);var r=ContentBounds;
        if(Pixels!=null){Bounds=new RectangleF(Bounds.X,Bounds.Y,width,height);return;}
        float sx=width/r.Width,sy=height/r.Height;for(int i=0;i<Points.Count;i++)Points[i]=new PointF(r.X+(Points[i].X-r.X)*sx,r.Y+(Points[i].Y-r.Y)*sy);Bounds=new RectangleF(r.X+(Bounds.X-r.X)*sx,r.Y+(Bounds.Y-r.Y)*sy,Math.Max(1,Bounds.Width*sx),Math.Max(1,Bounds.Height*sy));Width*=Math.Min(sx,sy);ClearCache();
    }
}
public sealed class EditState {
    public Bitmap Image;public List<Layer> Layers;public ColorSettings Adjustments;public bool Transformed,BackgroundVisible;public int Selected;
}
public sealed class EditorCanvas : Control {
    public Bitmap Image;public List<Layer> Layers=new List<Layer>();public string Tool="Move";
    public Color Ink=Color.FromArgb(211,163,105);public float BrushSize=12,InkOpacity=1,Zoom=1,MaskSoftness=.3f;
    public ColorSettings BackgroundAdjustments=new ColorSettings();
    public float Brightness{get{return BackgroundAdjustments.Brightness;}set{BackgroundAdjustments.Brightness=value;}}
    public float Contrast{get{return BackgroundAdjustments.Contrast;}set{BackgroundAdjustments.Contrast=value;}}
    public float Saturation{get{return BackgroundAdjustments.Saturation;}set{BackgroundAdjustments.Saturation=value;}}
    public bool FillShapes,Transformed,BackgroundVisible=true,ShowMask;public int Selected=-1;
    public Action Changed;public Action<string> Status;public string TextToPaint="Your text";
    readonly List<EditState> undo=new List<EditState>(),redo=new List<EditState>();
    readonly HashSet<Bitmap> assets=new HashSet<Bitmap>();
    Bitmap backgroundCache;string backgroundKey;
    PointF anchor,last,pan=new PointF();Layer pending;bool dragging,panning,paintingMask;RectangleF crop;
    public EditorCanvas(){DoubleBuffered=true;BackColor=Theme.Inset;Dock=DockStyle.Fill;TabStop=true;SetStyle(ControlStyles.ResizeRedraw,true);}
    public Layer ActiveLayer{get{return Selected>=0&&Selected<Layers.Count?Layers[Selected]:null;}}
    public bool IsClean{get{return Layers.Count==0&&BackgroundVisible&&BackgroundAdjustments.Neutral&&!Transformed;}}
    public void Own(Bitmap bitmap){if(bitmap!=null)assets.Add(bitmap);}
    void Track(){Own(Image);foreach(var l in Layers){Own(l.Pixels);Own(l.Mask);}}
    void ClearLayerCaches(IEnumerable<Layer> layers){foreach(var l in layers)l.ClearCache();}
    void Collect(){
        Track();var used=new HashSet<Bitmap>();if(Image!=null)used.Add(Image);foreach(var l in Layers){if(l.Pixels!=null)used.Add(l.Pixels);if(l.Mask!=null)used.Add(l.Mask);}foreach(var s in undo.Concat(redo)){used.Add(s.Image);foreach(var l in s.Layers){if(l.Pixels!=null)used.Add(l.Pixels);if(l.Mask!=null)used.Add(l.Mask);}}
        foreach(var b in assets.Where(b=>!used.Contains(b)).ToList()){b.Dispose();assets.Remove(b);}
    }
    void ClearBackgroundCache(){if(backgroundCache!=null){backgroundCache.Dispose();backgroundCache=null;}backgroundKey=null;}
    public void Replace(Bitmap image){
        Track();ClearLayerCaches(Layers);ClearBackgroundCache();foreach(var b in assets)if(b!=image)b.Dispose();assets.Clear();Own(image);Image=image;Layers.Clear();undo.Clear();redo.Clear();Selected=-1;BackgroundAdjustments=new ColorSettings();BackgroundVisible=true;Transformed=false;pending=null;Zoom=1;pan=new PointF();ShowMask=false;Invalidate();Notify();
    }
    EditState Snapshot(){Track();return new EditState{Image=Image,Layers=Layers.Select(l=>l.Clone()).ToList(),Adjustments=BackgroundAdjustments.Clone(),Transformed=Transformed,BackgroundVisible=BackgroundVisible,Selected=Selected};}
    public void Remember(){undo.Add(Snapshot());if(undo.Count>30)undo.RemoveAt(0);redo.Clear();Collect();}
    void Restore(EditState s){ClearLayerCaches(Layers);ClearBackgroundCache();Image=s.Image;Layers=s.Layers.Select(l=>l.Clone()).ToList();BackgroundAdjustments=s.Adjustments.Clone();Transformed=s.Transformed;BackgroundVisible=s.BackgroundVisible;Selected=s.Selected;Collect();Invalidate();Notify();}
    public void Undo(){if(undo.Count==0)return;redo.Add(Snapshot());var s=undo.Last();undo.RemoveAt(undo.Count-1);Restore(s);}
    public void Redo(){if(redo.Count==0)return;undo.Add(Snapshot());var s=redo.Last();redo.RemoveAt(redo.Count-1);Restore(s);}
    void Notify(){if(Changed!=null)Changed();}
    public void Commit(){Track();Invalidate();Notify();}
    public void DeleteSelected(){if(ActiveLayer==null||ActiveLayer.Locked)return;Remember();ActiveLayer.ClearCache();Layers.RemoveAt(Selected);Selected=Math.Min(Selected,Layers.Count-1);Commit();}
    public void AddImage(Bitmap bitmap,string name){Remember();Own(bitmap);float s=Math.Min(1,Math.Min(Image.Width/(float)bitmap.Width,Image.Height/(float)bitmap.Height));Layers.Add(new Layer{Kind="Image",Name=name,Pixels=bitmap,Bounds=new RectangleF((Image.Width-bitmap.Width*s)/2,(Image.Height-bitmap.Height*s)/2,bitmap.Width*s,bitmap.Height*s)});Selected=Layers.Count-1;Commit();}
    public void LiftBackground(){Remember();Layers.Insert(0,new Layer{Kind="Image",Name="Original photo",Pixels=Image,Bounds=new RectangleF(0,0,Image.Width,Image.Height),Adjustments=BackgroundAdjustments.Clone()});BackgroundVisible=false;BackgroundAdjustments=new ColorSettings();Selected=0;Commit();}
    public void ResizeDocument(int width,int height){
        if(width<1||height<1||width>20000||height>20000||(long)width*height>120000000)throw new InvalidOperationException("Choose a canvas up to 120 megapixels.");
        Remember();float dx=(width-Image.Width)/2f,dy=(height-Image.Height)/2f;
        if(BackgroundVisible)Layers.Insert(0,new Layer{Kind="Image",Name="Original photo",Pixels=Image,Bounds=new RectangleF(0,0,Image.Width,Image.Height),Adjustments=BackgroundAdjustments.Clone()});
        foreach(var l in Layers){
            if(l.Kind=="Adjustment"){
                if(l.Mask!=null){float scale=Math.Min(1,2048f/Math.Max(width,height));var mask=Pixels.SolidMask(Math.Max(1,(int)(width*scale)),Math.Max(1,(int)(height*scale)),false);using(var g=Graphics.FromImage(mask))g.DrawImage(l.Mask,new RectangleF(dx*scale,dy*scale,Image.Width*scale,Image.Height*scale));Own(mask);l.Mask=mask;}l.Bounds=new RectangleF(0,0,width,height);
            }else l.Move(dx,dy);
        }
        Image=new Bitmap(width,height,PixelFormat.Format32bppArgb);Own(Image);BackgroundVisible=false;BackgroundAdjustments=new ColorSettings();Transformed=true;Selected=-1;ClearBackgroundCache();Fit();Commit();
    }
    public void Fit(){Zoom=1;pan=new PointF();Invalidate();}
    public new float Scale{get{return Image==null?1:Math.Max(.005f,Math.Min((Width-64f)/Image.Width,(Height-64f)/Image.Height)*Zoom);}}
    PointF Offset{get{return Image==null?new PointF():new PointF((Width-Image.Width*Scale)/2+pan.X,(Height-Image.Height*Scale)/2+pan.Y);}}
    PointF ToImage(Point p){var o=Offset;return new PointF((p.X-o.X)/Scale,(p.Y-o.Y)/Scale);}
    bool Inside(PointF p){return Image!=null&&p.X>=0&&p.Y>=0&&p.X<Image.Width&&p.Y<Image.Height;}
    public static ColorMatrix Matrix(float brightness,float contrast,float saturation){float sr=(1-saturation)*.213f,sg=(1-saturation)*.715f,sb=(1-saturation)*.072f,shift=(1-contrast)/2+brightness;return new ColorMatrix(new[]{new[]{(sr+saturation)*contrast,sr*contrast,sr*contrast,0,0},new[]{sg*contrast,(sg+saturation)*contrast,sg*contrast,0,0},new[]{sb*contrast,sb*contrast,(sb+saturation)*contrast,0,0},new[]{0f,0f,0f,1f,0f},new[]{shift,shift,shift,0,1}});}
    static void Quality(Graphics g){g.CompositingQuality=CompositingQuality.HighQuality;g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.SmoothingMode=SmoothingMode.AntiAlias;g.PixelOffsetMode=PixelOffsetMode.HighQuality;}
    Bitmap Background(int maxEdge){string key=BackgroundAdjustments.Key+"/"+maxEdge;if(backgroundCache==null||backgroundKey!=key){ClearBackgroundCache();backgroundCache=Pixels.Copy(Image,maxEdge);Pixels.Adjust(backgroundCache,BackgroundAdjustments);RasterFilters.Apply(backgroundCache,BackgroundAdjustments,backgroundCache.Width/(float)Image.Width);backgroundKey=key;}return backgroundCache;}
    Bitmap LayerPlane(Layer l,int w,int h,int maxEdge){var b=new Bitmap(w,h,PixelFormat.Format32bppArgb);using(var g=Graphics.FromImage(b)){Quality(g);g.ScaleTransform(w/(float)Image.Width,h/(float)Image.Height);l.Draw(g,maxEdge);}return b;}
    public Bitmap Render(int w,int h,bool jpeg=false){return Composite(w,h,jpeg,0);}
    Bitmap Composite(int w,int h,bool jpeg,int maxEdge){
        if(Image==null)throw new InvalidOperationException("Open an image first.");if(w<1||h<1||w>20000||h>20000||(long)w*h>120000000)throw new InvalidOperationException("Choose dimensions up to 20,000 pixels per side and 120 megapixels total.");
        var b=new Bitmap(w,h,PixelFormat.Format32bppArgb);
        try{using(var g=Graphics.FromImage(b)){Quality(g);if(BackgroundVisible)g.DrawImage(Background(maxEdge),new Rectangle(0,0,w,h));}
            for(int i=0;i<Layers.Count;i++){var l=Layers[i];if(!l.Visible)continue;
                if(l.Kind=="Adjustment"){using(var adjusted=Pixels.Copy(b)){Pixels.Adjust(adjusted,l.Adjustments);RasterFilters.Apply(adjusted,l.Adjustments,w/(float)Image.Width);var original=Pixels.Read(b);var altered=Pixels.Read(adjusted);Bitmap coverage=null;try{byte[] mask=null;if(l.Mask!=null&&l.MaskEnabled){coverage=new Bitmap(w,h);using(var mg=Graphics.FromImage(coverage))mg.DrawImage(l.Mask,new Rectangle(0,0,w,h));mask=Pixels.Read(coverage);}for(int p=0;p<original.Length;p+=4){float amount=l.Opacity*(mask==null?1:mask[p]/255f);for(int channel=0;channel<3;channel++)original[p+channel]=(byte)(original[p+channel]*(1-amount)+altered[p+channel]*amount);}Pixels.Write(b,original);}finally{if(coverage!=null)coverage.Dispose();}}continue;}
                if(l.Blend=="Normal"&&!l.ClipToBelow){using(var g=Graphics.FromImage(b)){Quality(g);g.ScaleTransform(w/(float)Image.Width,h/(float)Image.Height);l.Draw(g,maxEdge);}}
                else{using(var plane=LayerPlane(l,w,h,maxEdge)){Bitmap clipping=null;try{if(l.ClipToBelow){if(i==0)continue;clipping=LayerPlane(Layers[i-1],w,h,maxEdge);}Pixels.Blend(b,plane,l.Blend,clipping);}finally{if(clipping!=null)clipping.Dispose();}}}
            }
            if(pending!=null)using(var g=Graphics.FromImage(b)){Quality(g);g.ScaleTransform(w/(float)Image.Width,h/(float)Image.Height);pending.Draw(g,maxEdge);}
            if(jpeg){var white=new Bitmap(w,h,PixelFormat.Format32bppArgb);using(var g=Graphics.FromImage(white)){g.Clear(Color.White);g.DrawImageUnscaled(b,0,0);}b.Dispose();b=white;}return b;
        }catch{b.Dispose();throw;}
    }
    public void Rotate(){Remember();var b=Render(Image.Width,Image.Height);b.RotateFlip(RotateFlipType.Rotate90FlipNone);Own(b);Image=b;ClearLayerCaches(Layers);Layers.Clear();Selected=-1;BackgroundAdjustments=new ColorSettings();BackgroundVisible=true;Transformed=true;ClearBackgroundCache();Fit();Notify();}
    public void Flip(){Remember();var b=Render(Image.Width,Image.Height);b.RotateFlip(RotateFlipType.RotateNoneFlipX);Own(b);Image=b;ClearLayerCaches(Layers);Layers.Clear();Selected=-1;BackgroundAdjustments=new ColorSettings();BackgroundVisible=true;Transformed=true;ClearBackgroundCache();Commit();}
    public void SetMask(Bitmap mask){var l=ActiveLayer;if(l==null||l.Locked){if(mask!=null)mask.Dispose();return;}Remember();Own(mask);l.Mask=mask;l.MaskEnabled=true;l.ClearCache();Commit();}
    public Size MaskSize(){var l=ActiveLayer;var r=l.ContentBounds;float w=l.Pixels==null?r.Width:l.Pixels.Width,h=l.Pixels==null?r.Height:l.Pixels.Height;float scale=Math.Min(1,2048/Math.Max(w,h));return new Size(Math.Max(1,(int)(w*scale)),Math.Max(1,(int)(h*scale)));}
    public void StartMask(bool reveal){if(ActiveLayer==null||ActiveLayer.Locked)return;var size=MaskSize();SetMask(Pixels.SolidMask(size.Width,size.Height,reveal));}
    void BeginMask(){var l=ActiveLayer;if(l==null||l.Locked)return;Remember();if(l.Mask==null){var s=MaskSize();l.Mask=Pixels.SolidMask(s.Width,s.Height,true);}else l.Mask=Pixels.Copy(l.Mask);Own(l.Mask);l.MaskEnabled=true;paintingMask=true;}
    public void PaintMask(PointF from,PointF to,bool reveal){
        var l=ActiveLayer;if(l==null||l.Locked||l.Mask==null)return;var a=l.LocalPoint(from);var b=l.LocalPoint(to);float sx=l.Mask.Width/l.ContentBounds.Width,sy=l.Mask.Height/l.ContentBounds.Height;float diameter=Math.Max(1,BrushSize*(sx+sy)/2);
        a=new PointF(a.X*l.Mask.Width,a.Y*l.Mask.Height);b=new PointF(b.X*l.Mask.Width,b.Y*l.Mask.Height);float distance=(float)Math.Sqrt((a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y));int steps=Math.Max(1,(int)Math.Ceiling(distance/Math.Max(1,diameter*.2f)));
        using(var g=Graphics.FromImage(l.Mask)){g.SmoothingMode=SmoothingMode.AntiAlias;int value=reveal?255:0;for(int i=0;i<=steps;i++){float x=a.X+(b.X-a.X)*i/steps,y=a.Y+(b.Y-a.Y)*i/steps;
                if(MaskSoftness<.02f){using(var ink=new SolidBrush(Color.FromArgb((int)(255*InkOpacity),value,value,value)))g.FillEllipse(ink,x-diameter/2,y-diameter/2,diameter,diameter);}
                else{using(var path=new GraphicsPath()){path.AddEllipse(x-diameter/2,y-diameter/2,diameter,diameter);using(var brush=new PathGradientBrush(path)){brush.CenterColor=Color.FromArgb((int)(255*InkOpacity),value,value,value);brush.SurroundColors=new[]{Color.FromArgb(0,value,value,value)};brush.FocusScales=new PointF(1-MaskSoftness,1-MaskSoftness);g.FillPath(brush,path);}}}
            }}l.ClearCache();Invalidate();
    }
    protected override void OnPaint(PaintEventArgs e){
        base.OnPaint(e);var g=e.Graphics;g.Clear(BackColor);if(Image==null)return;var o=Offset;float s=Scale;var destination=new RectangleF(o.X,o.Y,Image.Width*s,Image.Height*s);
        var previous=g.Save();g.SetClip(destination);using(var dark=new SolidBrush(Color.FromArgb(37,38,42)))using(var light=new SolidBrush(Color.FromArgb(49,50,54)))for(int y=Math.Max(0,(int)o.Y);y<Math.Min(Height,destination.Bottom);y+=14)for(int x=Math.Max(0,(int)o.X);x<Math.Min(Width,destination.Right);x+=14)g.FillRectangle(((x-(int)Math.Max(0,o.X))/14+(y-(int)Math.Max(0,o.Y))/14)%2==0?dark:light,x,y,14,14);
        int maxEdge=Math.Min(2000,Math.Max(600,(int)(Math.Max(Image.Width,Image.Height)*Math.Min(1,s))));float ratio=Math.Min(1,maxEdge/(float)Math.Max(Image.Width,Image.Height));
        using(var preview=Composite(Math.Max(1,(int)(Image.Width*ratio)),Math.Max(1,(int)(Image.Height*ratio)),false,maxEdge)){Quality(g);g.DrawImage(preview,destination);}
        g.TranslateTransform(o.X,o.Y);g.ScaleTransform(s,s);
        var selected=ActiveLayer;if(selected!=null){var r=selected.ContentBounds;var state=g.Save();g.TranslateTransform(r.X+r.Width/2,r.Y+r.Height/2);g.RotateTransform(selected.Rotation);g.ScaleTransform(selected.FlipX?-1:1,selected.FlipY?-1:1);
            if(ShowMask&&selected.Mask!=null)using(var attrs=new ImageAttributes()){var cm=new ColorMatrix();cm.Matrix33=.65f;attrs.SetColorMatrix(cm);Layer.DrawBitmap(g,selected.Mask,new RectangleF(-r.Width/2,-r.Height/2,r.Width,r.Height),attrs);}
            using(var pen=new Pen(selected.Locked?Theme.Muted:Theme.Accent,1.5f/s)){pen.DashStyle=DashStyle.Dash;g.DrawRectangle(pen,-r.Width/2,-r.Height/2,r.Width,r.Height);}g.Restore(state);}
        if(crop.Width>0&&Tool=="Crop")using(var pen=new Pen(Color.White,2/s)){pen.DashStyle=DashStyle.Dash;g.DrawRectangle(pen,crop.X,crop.Y,crop.Width,crop.Height);}g.Restore(previous);using(var pen=new Pen(Theme.Line))g.DrawRectangle(pen,o.X,o.Y,destination.Width,destination.Height);
    }
    protected override void OnMouseDown(MouseEventArgs e){
        base.OnMouseDown(e);Focus();if(Image==null)return;if(e.Button==MouseButtons.Middle||Tool=="Hand"){panning=true;last=e.Location;Capture=true;return;}if(e.Button!=MouseButtons.Left)return;var p=ToImage(e.Location);if(!Inside(p))return;anchor=last=p;
        if(Tool=="Move"){Selected=-1;for(int i=Layers.Count-1;i>=0;i--)if(!Layers[i].Locked&&Layers[i].Kind!="Adjustment"&&Layers[i].Hit(p,6/Scale)){Selected=i;break;}if(Selected>=0){Remember();dragging=true;}Notify();Invalidate();}
        else if(Tool=="Mask hide"||Tool=="Mask reveal"||Tool=="Eraser"){if(ActiveLayer==null||ActiveLayer.Locked){if(Status!=null)Status("Select an unlocked layer first. Use Lift photo to edit the background mask.");return;}BeginMask();dragging=true;PaintMask(p,p,Tool=="Mask reveal");}
        else if(Tool=="Eyedropper"){using(var b=Composite(Math.Min(Image.Width,1600),Math.Max(1,(int)(Image.Height*Math.Min(Image.Width,1600)/(float)Image.Width)),false,1600)){Ink=b.GetPixel(Math.Min(b.Width-1,(int)(p.X*b.Width/Image.Width)),Math.Min(b.Height-1,(int)(p.Y*b.Height/Image.Height)));}Notify();if(Status!=null)Status("Picked #"+Ink.R.ToString("X2")+Ink.G.ToString("X2")+Ink.B.ToString("X2"));}
        else if(Tool=="Text"){Remember();Layers.Add(new Layer{Kind=Tool,Name="Text "+(Layers.Count+1),Text=TextToPaint,Color=Ink,Width=BrushSize,Opacity=InkOpacity,Bounds=new RectangleF(p.X,p.Y,Math.Max(1,TextToPaint.Length*BrushSize*2),BrushSize*4)});Selected=Layers.Count-1;Commit();}
        else if(Tool=="Crop"){crop=new RectangleF(p.X,p.Y,0,0);dragging=true;}
        else{Remember();pending=new Layer{Kind=Tool,Name=Tool+" "+(Layers.Count+1),Color=Ink,Width=BrushSize,Opacity=InkOpacity,Fill=FillShapes,Bounds=new RectangleF(p.X,p.Y,0,0)};pending.Points.Add(p);if(Tool=="Line")pending.Points.Add(p);dragging=true;}Capture=dragging;
    }
    protected override void OnMouseMove(MouseEventArgs e){
        base.OnMouseMove(e);if(Image==null)return;if(panning){pan.X+=e.X-last.X;pan.Y+=e.Y-last.Y;last=e.Location;Invalidate();return;}var p=ToImage(e.Location);if(Status!=null&&Inside(p))Status(((int)p.X)+", "+((int)p.Y)+" px   ·   "+Tool);if(!dragging)return;p.X=Math.Max(0,Math.Min(Image.Width,p.X));p.Y=Math.Max(0,Math.Min(Image.Height,p.Y));
        if(paintingMask)PaintMask(last,p,Tool=="Mask reveal");else if(Tool=="Move"&&ActiveLayer!=null&&!ActiveLayer.Locked)ActiveLayer.Move(p.X-last.X,p.Y-last.Y);else if(Tool=="Crop")crop=Rect(anchor,p);else if(pending!=null){if(Tool=="Brush")pending.Points.Add(p);else if(Tool=="Line")pending.Points[1]=p;else pending.Bounds=Rect(anchor,p);pending.ClearCache();}last=p;Invalidate();
    }
    static RectangleF Rect(PointF a,PointF b){return new RectangleF(Math.Min(a.X,b.X),Math.Min(a.Y,b.Y),Math.Abs(a.X-b.X),Math.Abs(a.Y-b.Y));}
    protected override void OnMouseUp(MouseEventArgs e){
        base.OnMouseUp(e);if(pending!=null){Layers.Add(pending);Selected=Layers.Count-1;pending=null;}
        if(dragging&&Tool=="Crop"&&crop.Width>=2&&crop.Height>=2){Remember();using(var full=Render(Image.Width,Image.Height)){var bounds=Rectangle.Intersect(Rectangle.Round(crop),new Rectangle(0,0,full.Width,full.Height));Image=full.Clone(bounds,PixelFormat.Format32bppArgb);Own(Image);}ClearLayerCaches(Layers);Layers.Clear();Selected=-1;BackgroundAdjustments=new ColorSettings();BackgroundVisible=true;Transformed=true;ClearBackgroundCache();crop=RectangleF.Empty;Fit();}
        bool changed=dragging;dragging=panning=paintingMask=false;Capture=false;Invalidate();if(changed)Commit();
    }
    protected override void OnMouseWheel(MouseEventArgs e){base.OnMouseWheel(e);Zoom=Math.Max(.15f,Math.Min(12,Zoom*(e.Delta>0?1.15f:1/1.15f)));Invalidate();}
    protected override void Dispose(bool disposing){if(disposing){Track();ClearLayerCaches(Layers);if(pending!=null)pending.ClearCache();ClearBackgroundCache();foreach(var b in assets)b.Dispose();assets.Clear();}base.Dispose(disposing);}
}
}
