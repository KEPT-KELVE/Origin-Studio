using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using System.Globalization;
using System.Collections.Generic;

namespace OriginStudio {
public sealed class DeviceForm : Form {
    public Device Selection;TextBox search;ComboBox brand;ListBox list;Label count;bool ready;
    public DeviceForm(string filter="All manufacturers") {
        Theme.Style(this);Text="Device catalog · Origin Studio";Size=new Size(670,640);MinimumSize=new Size(550,480);
        var title=Theme.Label("CHOOSE A CAMERA IDENTITY",true);title.SetBounds(18,18,450,24);Controls.Add(title);
        var hint=Theme.Label("One entry per named device. Brand and model stay editable in the inspector.");hint.AutoSize=false;hint.SetBounds(18,45,600,34);Controls.Add(hint);
        search=Theme.Edit();search.SetBounds(18,86,390,27);search.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;Controls.Add(search);
        brand=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,BackColor=Theme.Inset,ForeColor=Theme.Text,FlatStyle=FlatStyle.Flat};brand.Items.AddRange(new object[]{"All manufacturers","Apple","Samsung"});brand.SelectedItem=filter;brand.SetBounds(421,86,211,27);brand.Anchor=AnchorStyles.Right|AnchorStyles.Top;Controls.Add(brand);
        list=new ListBox{BackColor=Theme.Inset,ForeColor=Theme.Text,BorderStyle=BorderStyle.None,DrawMode=DrawMode.OwnerDrawFixed,ItemHeight=48};list.SetBounds(18,132,614,390);list.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Bottom;Controls.Add(list);
        list.DrawItem+=(s,e)=>{if(e.Index<0)return;var d=(Device)list.Items[e.Index];bool sel=(e.State&DrawItemState.Selected)!=0;using(var bg=new SolidBrush(sel?Color.FromArgb(65,53,87):Theme.Inset))e.Graphics.FillRectangle(bg,e.Bounds);using(var b=new SolidBrush(sel?Theme.Accent:Theme.Text))e.Graphics.DrawString(d.Name,Theme.Bold,b,e.Bounds.X+12,e.Bounds.Y+6);using(var b=new SolidBrush(Theme.Muted))e.Graphics.DrawString(d.Make+"  /  "+d.Model,Theme.Small,b,e.Bounds.X+12,e.Bounds.Y+27);};
        count=Theme.Label("");count.AutoSize=false;count.SetBounds(18,535,370,35);count.Anchor=AnchorStyles.Bottom|AnchorStyles.Left;Controls.Add(count);
        var apply=Theme.Button("Apply device",()=>Apply(),true);apply.SetBounds(465,535,167,36);apply.Anchor=AnchorStyles.Bottom|AnchorStyles.Right;Controls.Add(apply);
        list.DoubleClick+=(s,e)=>Apply();search.TextChanged+=(s,e)=>{if(ready)Filter();};brand.SelectedIndexChanged+=(s,e)=>{if(ready)Filter();};ready=true;Filter();
        Shown+=(s,e)=>search.Focus();
    }
    void Filter(){var q=search.Text.Trim().ToLowerInvariant();string b=(string)brand.SelectedItem;list.BeginUpdate();list.Items.Clear();var parts=q.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries);foreach(var d in Device.All){if(b=="Apple"&&d.Make!="Apple"||b=="Samsung"&&d.Make=="Apple")continue;string match=(d.Name+" "+d.Model).ToLowerInvariant();if(parts.All(p=>match.Contains(p)))list.Items.Add(d);}if(list.Items.Count>0)list.SelectedIndex=0;list.EndUpdate();count.Text=list.Items.Count.ToString("N0")+" matching devices";}
    void Apply(){if(list.SelectedItem==null)return;Selection=(Device)list.SelectedItem;DialogResult=DialogResult.OK;Close();}
}
public sealed class RawMetadataForm : Form {
    Metadata source;DataGridView grid;public Metadata Result;
    public RawMetadataForm(Metadata m) {
        source=m.Clone();Theme.Style(this);Text="Raw EXIF inspector · Origin Studio";Size=new Size(980,630);MinimumSize=new Size(740,500);
        var hint=Theme.Label("Edit standard or custom EXIF tags. Blank values delete tags. Use a hex ID (e.g. 010F) and type 1–12.");hint.Dock=DockStyle.Top;hint.Height=42;hint.Padding=new Padding(12);Controls.Add(hint);
        grid=new DataGridView{Dock=DockStyle.Fill,BackgroundColor=Theme.Inset,BorderStyle=BorderStyle.None,GridColor=Theme.Line,AllowUserToAddRows=true,AllowUserToDeleteRows=true,RowHeadersVisible=false,EnableHeadersVisualStyles=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill};
        grid.DefaultCellStyle.BackColor=Theme.Inset;grid.DefaultCellStyle.ForeColor=Theme.Text;grid.DefaultCellStyle.SelectionBackColor=Color.FromArgb(64,51,85);grid.DefaultCellStyle.SelectionForeColor=Theme.Text;grid.ColumnHeadersDefaultCellStyle.BackColor=Theme.Panel;grid.ColumnHeadersDefaultCellStyle.ForeColor=Theme.Muted;
        var group=new DataGridViewComboBoxColumn{Name="Group",FillWeight=13};group.Items.AddRange("IFD0","Exif","GPS","Interop");grid.Columns.Add(group);grid.Columns.Add(new DataGridViewTextBoxColumn{Name="ID",FillWeight=9});grid.Columns.Add(new DataGridViewTextBoxColumn{Name="Type",FillWeight=7});grid.Columns.Add(new DataGridViewTextBoxColumn{Name="Name",ReadOnly=true,FillWeight=23});grid.Columns.Add(new DataGridViewTextBoxColumn{Name="Value",FillWeight=48});
        foreach(var t in m.Tags.OrderBy(t=>t.Group).ThenBy(t=>t.Id)){string name;Metadata.Names.TryGetValue(t.Id,out name);grid.Rows.Add(t.Group,t.Id.ToString("X4"),t.Type.ToString(),name??"Custom tag",Metadata.Display(t));}grid.DataError+=(s,e)=>e.ThrowException=false;Controls.Add(grid);grid.BringToFront();
        var bottom=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=68,Padding=new Padding(12),BackColor=Theme.Panel};var save=Theme.Button("Apply EXIF edits",()=>Save(),true);save.Width=155;bottom.Controls.Add(save);var types=Theme.Label("1 byte · 2 ASCII · 3 short · 4 long · 5 rational · 7 hex bytes · 10 signed rational");types.AutoSize=false;types.Width=680;types.Height=35;bottom.Controls.Add(types);Controls.Add(bottom);bottom.BringToFront();
    }
    void Save(){try{grid.EndEdit();var result=source.Clone();result.Tags.Clear();foreach(DataGridViewRow row in grid.Rows){if(row.IsNewRow)continue;string value=Convert.ToString(row.Cells[4].Value);if(string.IsNullOrWhiteSpace(value))continue;string group=Convert.ToString(row.Cells[0].Value);if(!new[]{"IFD0","Exif","GPS","Interop"}.Contains(group))throw new FormatException("Choose a directory group for every row.");ushort id=ushort.Parse(Convert.ToString(row.Cells[1].Value).Replace("0x",""),NumberStyles.HexNumber);ushort type=ushort.Parse(Convert.ToString(row.Cells[2].Value));if(id==0x8769||id==0x8825||id==0xa005)throw new FormatException("Directory pointers are managed automatically.");result.Set(group,id,type,value);}Result=result;DialogResult=DialogResult.OK;Close();}catch(Exception ex){MessageBox.Show(this,ex.Message,"Check the EXIF value",MessageBoxButtons.OK,MessageBoxIcon.Information);}}
}
public sealed class ExportSettings {
    public string Path;public int Width,Height,Quality=95;public bool Png,Strip,Lossless=true,SetTimes=true;public DateTime? FileDate;
}
public sealed class ExportForm : Form {
    public ExportSettings Settings;TextBox filename,date;NumericUpDown width,height,quality;ComboBox format;CheckBox strip,lossless,times,ratio;int originalW,originalH;bool resizing;
    public ExportForm(string name,int w,int h,string taken,bool clean){
        Theme.Style(this);Text="Export image · Origin Studio";Size=new Size(560,570);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;originalW=w;originalH=h;
        var heading=Theme.Label("EXPORT YOUR IMAGE",true);heading.SetBounds(22,20,440,26);Controls.Add(heading);
        var sub=Theme.Label("The camera identity and location are written inside the exported file.");sub.AutoSize=false;sub.SetBounds(22,50,485,40);Controls.Add(sub);
        LabelAt("Filename",22,104);filename=Theme.Edit(System.IO.Path.GetFileNameWithoutExtension(name)+"_edited");filename.SetBounds(175,100,338,26);Controls.Add(filename);
        LabelAt("Format",22,145);format=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,BackColor=Theme.Inset,ForeColor=Theme.Text};format.Items.AddRange(new object[]{"JPEG · EXIF + XMP","PNG · EXIF + XMP"});format.SelectedIndex=0;format.SetBounds(175,141,338,26);Controls.Add(format);
        LabelAt("Dimensions",22,188);width=Number(w,1,20000);height=Number(h,1,20000);width.SetBounds(175,182,150,28);height.SetBounds(360,182,153,28);Controls.Add(width);Controls.Add(height);var x=Theme.Label("×");x.SetBounds(338,188,20,24);Controls.Add(x);
        ratio=Check("Lock aspect ratio",true);ratio.SetBounds(175,217,230,27);Controls.Add(ratio);
        LabelAt("JPEG quality",22,259);quality=Number(95,1,100);quality.SetBounds(175,253,150,28);Controls.Add(quality);
        lossless=Check("Keep original JPEG pixels when no visual edits were made",clean);lossless.SetBounds(22,297,493,28);lossless.Enabled=clean;Controls.Add(lossless);
        strip=Check("Remove all metadata instead of applying changes",false);strip.SetBounds(22,333,493,28);Controls.Add(strip);
        times=Check("Set exported file creation / modified time",true);times.SetBounds(22,372,493,27);Controls.Add(times);
        date=Theme.Edit(taken);date.SetBounds(22,407,490,27);Controls.Add(date);
        var note=Theme.Label("File size follows pixels and compression. Dimensions resize the actual image.");note.AutoSize=false;note.SetBounds(22,444,493,35);Controls.Add(note);
        var save=Theme.Button("Export image…",()=>Save(),true);save.SetBounds(325,485,188,36);Controls.Add(save);var cancel=Theme.Button("Cancel",()=>{DialogResult=DialogResult.Cancel;Close();});cancel.SetBounds(175,485,130,36);Controls.Add(cancel);
        width.ValueChanged+=(s,e)=>{if(resizing||!ratio.Checked)return;resizing=true;height.Value=(decimal)Math.Max(1,Math.Min(20000,Math.Round((double)width.Value*originalH/originalW)));resizing=false;};height.ValueChanged+=(s,e)=>{if(resizing||!ratio.Checked)return;resizing=true;width.Value=(decimal)Math.Max(1,Math.Min(20000,Math.Round((double)height.Value*originalW/originalH)));resizing=false;};format.SelectedIndexChanged+=(s,e)=>{quality.Enabled=format.SelectedIndex==0;lossless.Enabled=clean&&format.SelectedIndex==0;};
    }
    void LabelAt(string s,int x,int y){var l=Theme.Label(s);l.Location=new Point(x,y);Controls.Add(l);}
    static CheckBox Check(string text,bool check){return new CheckBox{Text=text,Checked=check,ForeColor=Theme.Text,Font=Theme.Font,AutoSize=false};}
    static NumericUpDown Number(int n,int min,int max){return new NumericUpDown{Minimum=min,Maximum=max,Value=Math.Min(max,Math.Max(min,n)),BackColor=Theme.Inset,ForeColor=Theme.Text,BorderStyle=BorderStyle.FixedSingle};}
    void Save(){
        try{
            if((long)width.Value*(long)height.Value>120000000)throw new FormatException("Use 120 megapixels or less.");if(filename.Text.IndexOfAny(System.IO.Path.GetInvalidFileNameChars())>=0||string.IsNullOrWhiteSpace(filename.Text))throw new FormatException("Choose a valid filename.");
            DateTime dt;DateTime? time=null;if(times.Checked){if(!DateTime.TryParseExact(date.Text,new[]{"yyyy:MM:dd HH:mm:ss","yyyy-MM-dd HH:mm:ss","yyyy-MM-ddTHH:mm:ss"},CultureInfo.InvariantCulture,DateTimeStyles.None,out dt))throw new FormatException("File date: yyyy:MM:dd HH:mm:ss");time=dt;}
            using(var dlg=new SaveFileDialog{Filter=format.SelectedIndex==0?"JPEG image|*.jpg":"PNG image|*.png",FileName=filename.Text,AddExtension=true,OverwritePrompt=true})if(dlg.ShowDialog(this)==DialogResult.OK){Settings=new ExportSettings{Path=dlg.FileName,Width=(int)width.Value,Height=(int)height.Value,Quality=(int)quality.Value,Png=format.SelectedIndex==1,Strip=strip.Checked,Lossless=lossless.Checked&&lossless.Enabled,SetTimes=times.Checked,FileDate=time};DialogResult=DialogResult.OK;Close();}
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"Check export settings",MessageBoxButtons.OK,MessageBoxIcon.Information);}
    }
}
public static class Prompt {
    public static string Ask(Form owner,string title,string initial="") {using(var f=new Form()){Theme.Style(f);f.Text=title;f.Size=new Size(450,160);f.FormBorderStyle=FormBorderStyle.FixedDialog;f.MaximizeBox=f.MinimizeBox=false;var t=Theme.Edit(initial);t.SetBounds(18,20,396,28);f.Controls.Add(t);var ok=Theme.Button("Apply",()=>{f.DialogResult=DialogResult.OK;f.Close();},true);ok.SetBounds(299,62,115,34);f.Controls.Add(ok);f.AcceptButton=ok;f.Shown+=(s,e)=>t.Focus();return f.ShowDialog(owner)==DialogResult.OK?t.Text:null;}}
}
}
