using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace OriginStudio {
public static class StartupLog {
    public static string DirectoryPath {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OriginStudio");}}
    public static string LogPath {get{return Path.Combine(DirectoryPath,"startup.log");}}
    static readonly object gate=new object();
    static bool reporting;
    public static bool HadError {get;private set;}
    public static void Begin(){
        try {Directory.CreateDirectory(DirectoryPath);File.WriteAllText(LogPath,"");File.Delete(Path.Combine(DirectoryPath,"startup-reported.flag"));}catch{}
        Write("Origin Studio 1.1 starting");
        Write("OS: "+Environment.OSVersion+"; CLR: "+Environment.Version+"; process: "+(IntPtr.Size*8)+" bit; OS64: "+Environment.Is64BitOperatingSystem);
        Write("Application: "+Assembly.GetExecutingAssembly().Location);
    }
    public static void Write(string message){
        try {lock(gate){Directory.CreateDirectory(DirectoryPath);File.AppendAllText(LogPath,DateTime.UtcNow.ToString("o")+"  "+message+Environment.NewLine);}}catch{}
    }
    public static void Report(Exception ex){
        if(ex==null||reporting)return;reporting=true;HadError=true;
        try {
            Write("STARTUP / APPLICATION ERROR\n"+ex);
            try {File.AppendAllText(Path.Combine(DirectoryPath,"errors.log"),DateTime.UtcNow.ToString("o")+"\n"+ex+Environment.NewLine);File.WriteAllText(Path.Combine(DirectoryPath,"startup-reported.flag"),"Error shown to user");}catch{}
            string message="Origin Studio could not continue.\n\n"+ex.GetBaseException().Message+"\n\nDetails were saved to:\n"+LogPath+"\n\nSend the contents of startup.log so this failure can be fixed.";
            if(Environment.OSVersion.Platform==PlatformID.Win32NT)NativeMessageBox(IntPtr.Zero,message,"Origin Studio — startup error",0x10|0x10000);
            else ShowManagedError(message);
        }catch{}finally{reporting=false;}
    }
    [DllImport("user32.dll",EntryPoint="MessageBoxW",CharSet=CharSet.Unicode)]
    static extern int NativeMessageBox(IntPtr owner,string message,string title,uint flags);
    [MethodImpl(MethodImplOptions.NoInlining)]
    static void ShowManagedError(string message){MessageBox.Show(message,"Origin Studio",MessageBoxButtons.OK,MessageBoxIcon.Error);}
}
static class EditorStartup {
    public static int Run(string[] args){
        StartupLog.Write("Loading Windows Forms");
        Application.ThreadException+=(s,e)=>StartupLog.Report(e.Exception);
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        StartupLog.Write("Windows Forms initialized");
        try {Device.Load();StartupLog.Write("Device catalog loaded: "+Device.All.Count+" entries");}
        catch(Exception ex){StartupLog.Write("Device catalog unavailable; custom camera fields remain usable. "+ex);}
        StartupLog.Write("Creating editor window");
        bool shown=false;
        using(var window=new MainWindow()){
            StartupLog.Write("Editor window constructed");
            window.Shown+=(s,e)=>{shown=true;StartupLog.Write("Editor window shown");};
            if(args.Length==2&&(args[0]=="--qa-screenshot"||args[0]=="--startup-test")){
                window.Shown+=(s,e)=>{
                    var timer=new Timer{Interval=1200};
                    timer.Tick+=(ss,ee)=>{
                        timer.Stop();timer.Dispose();
                        if(args[0]=="--qa-screenshot")using(var b=new System.Drawing.Bitmap(window.Width,window.Height)){
                            using(var g=System.Drawing.Graphics.FromImage(b))g.CopyFromScreen(window.Location,System.Drawing.Point.Empty,window.Size);
                            b.Save(args[1],System.Drawing.Imaging.ImageFormat.Png);
                        }
                        else File.WriteAllText(args[1],"Origin Studio 1.1 opened successfully.");
                        window.Close();
                    };timer.Start();
                };
            }
            Application.Run(window);
        }
        if(!shown)throw new InvalidOperationException("The editor closed before its window was shown.");
        StartupLog.Write("Editor closed normally");return StartupLog.HadError?1:0;
    }
}
}
