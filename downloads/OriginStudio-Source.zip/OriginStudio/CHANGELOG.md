# Origin Studio release notes

## 1.1 — Editor expansion

- Added imported image layers, adjustment layers, seven blend modes, layer locking and independent transforms.
- Added reversible image and shape masks, hide/reveal brushes, feathering, inversion, clipping and colour-based cutouts.
- Expanded colour editing to twenty controls, with reusable grades and built-in looks.
- Added gradients, editable typography, shadows, outlines, clipboard images and canvas resizing.
- Preserved compatibility with 1.0 projects; 1.1 projects now retain image pixels, masks and all layer settings.
- Consolidated device variants into friendly entries: 54 iPhones and 755 named Samsung devices.
- Added model-aware synthetic software generation, automatic lens labels and generated sample body serials.
- Retained automatic import of real metadata and export of EXIF, GPS and XMP.
- Kept direct standalone EXE packaging and version-specific installation paths. Startup diagnostics are not included.

## 1.0 — Initial public release

Native Windows drawing and metadata editor, with JPEG/PNG export, searchable device presets, location tools and editable projects.
