@echo off
setlocal
cd /d "%~dp0"
if not exist build mkdir build
set "ORIGIN_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%ORIGIN_CSC%" set "ORIGIN_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%ORIGIN_CSC%" (
  echo .NET Framework C# compiler was not found.
  pause
  exit /b 1
)
set "ORIGIN_FRAMEWORK_DIR=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%ORIGIN_FRAMEWORK_DIR%\mscorlib.dll" set "ORIGIN_FRAMEWORK_DIR=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
"%ORIGIN_CSC%" /nologo /noconfig /nostdlib+ /target:winexe /platform:anycpu /optimize+ /out:build\OriginStudio.Editor.exe /reference:"%ORIGIN_FRAMEWORK_DIR%\mscorlib.dll" /reference:"%ORIGIN_FRAMEWORK_DIR%\System.dll" /reference:"%ORIGIN_FRAMEWORK_DIR%\System.Drawing.dll" /reference:"%ORIGIN_FRAMEWORK_DIR%\System.Windows.Forms.dll" /reference:"%ORIGIN_FRAMEWORK_DIR%\System.Core.dll" /reference:"%ORIGIN_FRAMEWORK_DIR%\System.Web.Extensions.dll" /reference:"%ORIGIN_FRAMEWORK_DIR%\System.Xml.dll" /win32icon:assets\origin.ico /win32manifest:app.manifest /resource:assets\devices.tsv,devices.tsv /resource:assets\sample.jpg,sample.jpg /resource:assets\origin.ico,origin.ico src\Program.cs src\Startup.cs src\MainWindow.cs src\Dialogs.cs src\Editor.cs src\EditorCore.cs src\ColorEngine.cs src\RasterFilters.cs src\StudioPanels.cs src\DeviceCatalog.cs src\Projects.cs src\Maps.cs src\Metadata.cs
if errorlevel 1 (
  echo Build failed. Source uses C# 5-compatible syntax and needs .NET Framework 4.8.
  pause
  exit /b 1
)
copy /y OriginStudio.Editor.exe.config build\OriginStudio.Editor.exe.config >nul
echo Built build\OriginStudio.Editor.exe
pause
