# Building Origin Studio 1.1

The editor is a C# 5-compatible Windows Forms application targeting .NET Framework 4.8. The device catalog, sample and icon are embedded in the editor assembly. The standalone EXE is the editor itself; there is no self-extracting launcher.

## Windows

Run `build-windows.cmd` to compile `build\OriginStudio.Editor.exe`. It uses the .NET Framework compiler installed with Windows and explicitly references the Windows framework assemblies. The runtime configuration is copied beside the build output.

Run `build-installer.cmd` to copy `deliverables\OriginStudio-1.1.exe` and compile `deliverables\OriginStudio-Setup-1.1.exe`. The installer requires NSIS 3 with `makensis.exe` on PATH. No NuGet packages are required for a Windows build.

## Linux cross-build

The cross-build requires Python 3, Mono, Microsoft.Net.Compilers (tested with 3.11.0), Microsoft.NETFramework.ReferenceAssemblies.net48 (tested with 1.0.3), and Mono.Cecil (tested with 0.11.6). Extract those packages and supply their paths:

```sh
python3 build-cross.py \
  --mono /path/to/mono \
  --csc /path/to/compiler/tools/csc.exe \
  --framework /path/to/net48/build/.NETFramework/v4.8 \
  --cecil /path/to/cecil/lib/net40/Mono.Cecil.dll
```

Add `--tests` for metadata, native UI and editor-rendering checks; the GUI checks require a working graphical display. Add `--makensis /path/to/makensis` to compile the installer. A Linux NSIS installation may need `NSISDIR` set to its data directory.

The script uses `/noconfig /nostdlib+` and absolute paths to Microsoft's Windows reference assemblies. Do not replace these with `/lib` and short assembly names: the compiler may otherwise resolve references from the host's Mono runtime and generate calls unavailable on Windows.

`tools/FrameworkAudit.cs` checks the compiled editor's external framework member references strictly against the supplied Windows assemblies. Mono.Cecil and the other build dependencies are not distributed with the application.

## Packaging

The public version is 1.1; assembly and manifest versions are 1.1.0.0. Keep the values in Program.cs, Startup.cs, MainWindow.cs, app.manifest, build-cross.py, build-installer.cmd and installer.nsi consistent.

The installer deploys the direct editor to `Versions\1.1` inside the selected installation folder. Shortcuts and the uninstall registry entry point to that editor. It removes any development-only startup diagnostics shortcut and command file left by earlier installers. New installations do not include either item. Basic internal error logging remains optional and cannot block startup.

The release archive contains the installer, standalone EXE, user README, changelog, catalog credits and a folder for screenshots. The source archive also contains this build guide and the verification tools. No debug binaries or diagnostic launcher are included.

## Validation scope

The 1.1 editor passed 45 metadata/core checks, 43 native GUI checks and 51 editor checks under Mono. These cover device deduplication, generated metadata, independent image layers, blend formulas, clipping, mask brush undo/redo, colour effects, project pixel round-trips and legacy projects. The Windows framework reference audit found no missing members.

For release packaging, rebuild and audit the current editor, exercise its production startup, and compile the NSIS installer. These local checks are not a substitute for testing installation on Windows. Executables produced by these scripts are unsigned; signing requires the publisher's own certificate.

## Source map

| File | Responsibility |
|---|---|
| `EditorCore.cs` | Layer model, compositor, canvas interaction and undo/redo |
| `ColorEngine.cs` / `RasterFilters.cs` | Colour, alpha, masks and image filters |
| `StudioPanels.cs` | Layer, colour, mask, typography and composition controls |
| `Projects.cs` | Versioned project persistence and validation |
| `DeviceCatalog.cs` | Friendly device grouping and synthetic metadata generation |
| `Metadata.cs` / `Maps.cs` | EXIF/XMP and location tools |
| `Startup.cs` / `Program.cs` | Protected native editor startup |

The underlying photo and imported images are retained separately from adjustment settings and masks. Undo snapshots share immutable image assets, copying masks before brush edits. Mask resolution is capped at 2,048 pixels on the longest edge. Viewport rendering limits preview resolution; export uses source pixels. The renderer uses 8-bit RGB GDI+ and CPU filters.

PhotoCraft was reviewed for workflow ideas. No external editor source or binaries are bundled, and no Rust dependency was added.
