Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"
Name "Origin Studio 1.1"
OutFile "../deliverables/OriginStudio-Setup-1.1.exe"
InstallDir "$LOCALAPPDATA\Programs\Origin Studio"
InstallDirRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "InstallLocation"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "Origin Studio · Photo & Metadata"
!define MUI_ICON "assets/origin.ico"
!define MUI_UNICON "assets/origin.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\Versions\1.1\OriginStudio.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Launch Origin Studio"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
VIProductVersion "1.1.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "Origin Studio"
VIAddVersionKey /LANG=1033 "FileDescription" "Origin Studio Installer"
VIAddVersionKey /LANG=1033 "FileVersion" "1.1"
VIAddVersionKey /LANG=1033 "LegalCopyright" "Copyright 2026 Adam Ali"
Function .onInit
  ${If} ${RunningX64}
    SetRegView 64
  ${EndIf}
  ReadRegDWORD $0 HKLM "SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" "Release"
  ${If} $0 == ""
    SetRegView 32
    ReadRegDWORD $0 HKLM "SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" "Release"
  ${EndIf}
  SetRegView 32
  ${If} $0 < 528040
    MessageBox MB_OK|MB_ICONINFORMATION "Origin Studio needs .NET Framework 4.8, included with current Windows 10 and Windows 11. Install it from Microsoft and run this installer again."
    ExecShell "open" "https://dotnet.microsoft.com/en-us/download/dotnet-framework/net48"
    Abort
  ${EndIf}
FunctionEnd
Section "Origin Studio" SEC_APP
  ; Each release has its own directory. Upgrades do not overwrite a running
  ; legacy launcher or the editor belonging to another version.
  SetOutPath "$INSTDIR\Versions\1.1"
  SetOverwrite off
  File /oname=OriginStudio.exe "../deliverables/OriginStudio-1.1.exe"
  File /oname=OriginStudio.exe.config "OriginStudio.Editor.exe.config"
  SetOverwrite on
  SetOutPath "$INSTDIR"
  File "README.md"
  File "CHANGELOG.md"
  File "assets/catalog-sources.txt"
  ; Remove the development-only diagnostic tool and shortcut on upgrades.
  Delete "$INSTDIR\OriginStudio-Diagnostics.cmd"
  Delete "$SMPROGRAMS\Origin Studio\Startup diagnostics.lnk"
  CreateDirectory "$SMPROGRAMS\Origin Studio"
  CreateShortCut "$SMPROGRAMS\Origin Studio\Origin Studio.lnk" "$INSTDIR\Versions\1.1\OriginStudio.exe"
  CreateShortCut "$DESKTOP\Origin Studio.lnk" "$INSTDIR\Versions\1.1\OriginStudio.exe"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "DisplayName" "Origin Studio"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "DisplayVersion" "1.1"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "Publisher" "Adam Ali"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "DisplayIcon" "$INSTDIR\Versions\1.1\OriginStudio.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "ApplicationPath" "$INSTDIR\Versions\1.1\OriginStudio.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio" "NoRepair" 1
SectionEnd
Section "Uninstall"
  Delete "$INSTDIR\Versions\1.1\OriginStudio.exe"
  Delete "$INSTDIR\Versions\1.1\OriginStudio.exe.config"
  RMDir "$INSTDIR\Versions\1.1"
  Delete "$INSTDIR\Versions\1.0\OriginStudio.exe"
  Delete "$INSTDIR\Versions\1.0\OriginStudio.exe.config"
  RMDir "$INSTDIR\Versions\1.0"
  Delete "$INSTDIR\Versions\1.0.3\OriginStudio.exe"
  Delete "$INSTDIR\Versions\1.0.3\OriginStudio.exe.config"
  RMDir "$INSTDIR\Versions\1.0.3"
  RMDir "$INSTDIR\Versions"
  Delete "$INSTDIR\OriginStudio.exe"
  Delete "$INSTDIR\OriginStudio.exe.config"
  Delete "$INSTDIR\OriginStudio-Diagnostics.cmd"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\CHANGELOG.md"
  Delete "$INSTDIR\catalog-sources.txt"
  Delete "$INSTDIR\Uninstall.exe"
  Delete "$SMPROGRAMS\Origin Studio\Origin Studio.lnk"
  Delete "$SMPROGRAMS\Origin Studio\Startup diagnostics.lnk"
  RMDir "$SMPROGRAMS\Origin Studio"
  Delete "$DESKTOP\Origin Studio.lnk"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\OriginStudio"
  RMDir "$INSTDIR"
SectionEnd
