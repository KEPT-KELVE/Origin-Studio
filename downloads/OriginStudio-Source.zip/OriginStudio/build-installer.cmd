@echo off
setlocal
cd /d "%~dp0"
if not exist ..\deliverables mkdir ..\deliverables
where makensis.exe >nul 2>nul
if errorlevel 1 (
  echo Install NSIS 3 and add its folder to PATH, then run this script again.
  pause
  exit /b 1
)
copy /y build\OriginStudio.Editor.exe ..\deliverables\OriginStudio-1.1.exe >nul
if errorlevel 1 (
  echo Editor was not built. Run build-windows.cmd first.
  pause
  exit /b 1
)
makensis.exe installer.nsi
if errorlevel 1 (
  echo Installer build failed.
  pause
  exit /b 1
)
echo Built ..\deliverables\OriginStudio-1.1.exe and OriginStudio-Setup-1.1.exe
pause
