"""Build on Mono using genuine, explicitly pinned Windows framework assemblies.

Windows users can use build-windows.cmd instead. This cross-build requires the
Microsoft.Net.Compilers tools/csc.exe, Microsoft.NETFramework.ReferenceAssemblies
net48 build/.NETFramework/v4.8 directory, and Mono.Cecil lib/net40/Mono.Cecil.dll.
"""
import argparse
import pathlib
import shutil
import subprocess

VERSION = "1.1"

parser = argparse.ArgumentParser()
parser.add_argument("--mono", required=True)
parser.add_argument("--csc", required=True)
parser.add_argument("--framework", required=True)
parser.add_argument("--cecil", required=True)
parser.add_argument("--makensis")
parser.add_argument("--tests", action="store_true", help="Requires a working graphical display for GUI checks")
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parent
build = root / "build"
build.mkdir(exist_ok=True)
(root.parent / "deliverables").mkdir(exist_ok=True)
framework = pathlib.Path(args.framework).resolve()
references = [framework / (name + ".dll") for name in ["mscorlib", "System", "System.Drawing", "System.Windows.Forms", "System.Core", "System.Web.Extensions", "System.Xml"]]
if not all(path.is_file() for path in references):
    parser.error("The complete Windows .NET Framework 4.8 reference assembly directory is required")
common = [args.mono, args.csc, "/nologo", "/noconfig", "/nostdlib+", "/langversion:5", "/platform:anycpu", "/optimize+"]
# Absolute paths are essential: /lib alone searches the host CLR before /lib.
common += ["/reference:" + str(path) for path in references]
sources = ["src/Startup.cs", "src/MainWindow.cs", "src/Dialogs.cs", "src/Editor.cs", "src/EditorCore.cs", "src/ColorEngine.cs", "src/RasterFilters.cs", "src/StudioPanels.cs", "src/DeviceCatalog.cs", "src/Projects.cs", "src/Maps.cs", "src/Metadata.cs"]
resources = ["/resource:assets/devices.tsv,devices.tsv", "/resource:assets/sample.jpg,sample.jpg", "/resource:assets/origin.ico,origin.ico"]

def run(command):
    subprocess.run(command, cwd=root, check=True)

run(common + ["/target:winexe", "/out:build/OriginStudio.Editor.exe", "/win32icon:assets/origin.ico", "/win32manifest:app.manifest"] + resources + ["src/Program.cs"] + sources)
shutil.copy2(root / "OriginStudio.Editor.exe.config", build / "OriginStudio.Editor.exe.config")
cecil = pathlib.Path(args.cecil).resolve()
run(common + ["/target:exe", "/out:build/FrameworkAudit.exe", "/reference:" + str(cecil), "tools/FrameworkAudit.cs"])
shutil.copy2(cecil, build / "Mono.Cecil.dll")
run([args.mono, str(build / "FrameworkAudit.exe"), str(build / "OriginStudio.Editor.exe"), str(framework)])
# The editor is the standalone app. No self-extractor, cache or parent launcher
# is needed at runtime; all application assets are embedded in this assembly.
shutil.copy2(build / "OriginStudio.Editor.exe", root.parent / "deliverables" / ("OriginStudio-" + VERSION + ".exe"))
if args.tests:
    for name in ["CoreTests", "GuiTests", "EditorTests"]:
        run(common + ["/target:exe", "/out:build/" + name + ".exe"] + resources + ["src/" + name + ".cs"] + sources)
    output = build / "test-output"
    run([args.mono, str(build / "CoreTests.exe"), str(output), str(root / "assets/sample.jpg")])
    run([args.mono, str(build / "GuiTests.exe"), str(build / "gui.png"), str(output)])
    run([args.mono, str(build / "EditorTests.exe"), str(output)])
if args.makensis:
    run([args.makensis, "-V3", "installer.nsi"])
print("Build completed with audited Windows framework references.")
